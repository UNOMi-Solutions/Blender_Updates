# Authentication service for UNOMi Blender add-on
# Handles login/logout, token validation, user info, and session revoke
# against UNOMi's WordPress JWT endpoints. Persists token/mid to JSON.
import os
import json
import hashlib
import requests


class AuthService:
    def __init__(self):
        # set up endpoints and load any saved token/mid from disk
        self.endpoint = "https://getunomi.com/wp-json"
        self.app = "Blender-3d"
        self.token = ""
        self.mid = ""
        self.storage_path = os.path.join(os.path.dirname(__file__), "..", "auth_storage.json")
        self.storage_path = os.path.abspath(self.storage_path)
        self.load_stored_data()

    def device_id_hash(self):
        # make a short device fingerprint so the server can identify this machine
        try:
            import platform
            import uuid
            mac = hex(uuid.getnode())[2:].upper()
            system = platform.system()
            return hashlib.md5(f"{mac}_{system}".encode()).hexdigest()[:8]
        except Exception:
            return "12345678"

    def load_stored_data(self):
        # read token/mid from our small json file if it exists
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('token', '')
                    self.mid = data.get('mid', '')
        except Exception:
            self.token = ""
            self.mid = ""

    def save_stored_data(self):
        # write token/mid so the user stays logged in across restarts
        try:
            data = {'token': self.token, 'mid': self.mid}
            with open(self.storage_path, 'w') as f:
                json.dump(data, f)
        except Exception:
            pass

    def signin(self, email, password):
        # log the user in and store token if successful
        endpoints_to_try = [f"{self.endpoint}/jwt-auth/v1/token"]
        data = {'username': email, 'password': password, 'app': self.app, 'mid': self.mid}
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'UNOMi-Blender-Plugin/1.3.0',
            'Accept': 'application/json',
            'Origin': 'https://getunomi.com',
            'Referer': 'https://getunomi.com/'
        }
        try:
            _ = requests.get(endpoints_to_try[0], timeout=5)
        except Exception:
            pass
        for url in endpoints_to_try:
            try:
                response = requests.post(url, json=data, headers=headers, timeout=10)
                if response.status_code == 200:
                    if response.text.strip().startswith('<!DOCTYPE') or response.text.strip().startswith('<html'):
                        return {'success': False, 'error': 'API endpoint returned HTML instead of JSON. Server may be down.'}
                    try:
                        result = response.json()
                        if result.get('code') == 'jwt_auth_login_exceeded':
                            sessions = result.get('data', {}).get('sessions', [])
                            if sessions:
                                session_key = sessions[0]['key']
                                revoke_result = self.revoke_session(session_key)
                                if revoke_result:
                                    return self.signin(email, password)
                                else:
                                    return {'success': False, 'error': 'Failed to revoke existing session'}
                            else:
                                return {'success': False, 'error': 'No sessions to revoke'}
                        if 'token' in result:
                            self.token = result['token']
                            self.mid = result.get('mid', '')
                            self.save_stored_data()
                            return {'success': True, 'user': result.get('user', {}), 'subscription': result.get('subscription', {})}
                        else:
                            return {'success': False, 'error': result.get('message', 'Login failed')}
                    except json.JSONDecodeError:
                        return {'success': False, 'error': 'Invalid JSON response from server'}
                elif response.status_code == 403:
                    continue
                else:
                    response.raise_for_status()
            except requests.exceptions.RequestException:
                continue
            except Exception:
                continue
        return {'success': False, 'error': 'All authentication endpoints failed. The service may be unavailable or the API has changed.'}

    def revoke_session(self, session_key):
        # try a few payload shapes to revoke a previously active session on the server
        try:
            revoke_url = f"{self.endpoint}/jwt-auth/v1/token/revoke"
            revoke_formats = [
                {'key': session_key},
                {'session_key': session_key},
                {'token': session_key},
                {'session': session_key},
            ]
            revoke_headers = {
                'Content-Type': 'application/json',
                'User-Agent': 'UNOMi-Blender-Plugin/1.3.0',
                'Accept': 'application/json',
                'Origin': 'https://getunomi.com',
                'Referer': 'https://getunomi.com/'
            }
            for revoke_data in revoke_formats:
                response = requests.post(revoke_url, json=revoke_data, headers=revoke_headers, timeout=10)
                if response.status_code == 200:
                    return True
                elif response.status_code == 403:
                    continue
                else:
                    continue
            return False
        except Exception:
            return False

    def logout(self):
        # ask server to sign out, but always clear local token regardless
        try:
            if not self.token:
                return {'success': True, 'message': 'No active session'}
            logout_url = f"{self.endpoint}/jwt-auth/v1/signout"
            headers = {
                'Authorization': f'Bearer {self.token}',
                'Accept': 'application/json',
                'User-Agent': 'UNOMi-Blender-Plugin/1.3.0',
            }
            response = requests.post(logout_url, headers=headers, timeout=10)
            self.token = ""
            self.mid = ""
            self.save_stored_data()
            if response.status_code == 200:
                return {'success': True, 'message': 'Logged out successfully'}
            else:
                return {'success': True, 'message': 'Local session cleared (server logout failed)'}
        except Exception as e:
            self.token = ""
            self.mid = ""
            self.save_stored_data()
            return {'success': True, 'message': f'Local session cleared (error: {e})'}

    def validate_token(self):
        # check if our stored token is still valid
        if not self.token:
            return {'success': False, 'error': 'No token'}
        url = f"{self.endpoint}/jwt-auth/v1/token/validate"
        headers = {'Authorization': f'Bearer {self.token}'}
        try:
            response = requests.post(url, headers=headers, timeout=10)
            response.raise_for_status()
            return {'success': True}
        except Exception:
            return {'success': False, 'error': 'Invalid token'}

    def get_user_info(self):
        # fetch user and subscription info tied to our token
        if not self.token:
            return {'success': False, 'error': 'No token'}
        url = f"{self.endpoint}/jwt-auth/v1/token/validate/info"
        headers = {'Authorization': f'Bearer {self.token}'}
        try:
            response = requests.post(url, headers=headers, timeout=10)
            response.raise_for_status()
            result = response.json()
            return {'success': True, 'data': result.get('data', {})}
        except Exception:
            return {'success': False, 'error': 'Failed to get user info'}

    def signout(self):
        # convenience: perform logout and ensure local clear even if network fails
        try:
            _ = self.logout()
        except Exception:
            self.token = ""
            self.mid = ""
            self.save_stored_data()


auth_service = AuthService()



