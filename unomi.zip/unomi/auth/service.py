#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           3/01/26            Added token credit checks + consumption.
#Geanpierre Fernandez  7/31/26            Detect expired sessions on all auth calls; enable clean re-login.
#Geanpierre Fernandez  8/4/26             Increased auth request timeouts (10s -> 30s) for a slow server.

import os
import json
import hashlib
import requests


class AuthService:
    def __init__(self):
        self.base = "https://getunomi.com/wp-json/jwt-auth/v1"
        self.app = "BL3D" 
        self.token = ""
        self.mid = ""
        self.product_id = ""
        self.session_id = ""
        self.subscriptions = []

        self.storage_path = os.path.join(os.path.dirname(__file__), "..", "auth_storage.json")
        self.storage_path = os.path.abspath(self.storage_path)
        self.load_stored_data()

    # -------------------------
    # Device ID
    # -------------------------
    def device_id_hash(self):
        try:
            import platform
            import uuid
            mac = hex(uuid.getnode())[2:].upper()
            system = platform.system()
            return hashlib.md5(f"{mac}_{system}".encode()).hexdigest()[:8]
        except Exception:
            return "12345678"

    # -------------------------
    # Storage
    # -------------------------
    def load_stored_data(self):
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('token', '')
                    self.mid = data.get('mid', '')
                    self.product_id = data.get('product_id', '')
                    self.session_id = data.get('session_id', '')
        except Exception:
            pass

    def save_stored_data(self):
        try:
            data = {
                'token': self.token,
                'mid': self.mid,
                'product_id': self.product_id,
                'session_id': self.session_id
            }
            with open(self.storage_path, 'w') as f:
                json.dump(data, f)
        except Exception:
            pass

    # -------------------------
    # LOGIN (PDF compliant)
    # -------------------------
    def signin(self, email, password):
        url = f"{self.base}/app-login"

        payload = {
            "username": email,
            "password": password,
            "app": self.app,
            "mid": self.mid or self.device_id_hash()
        }

        # Proactively sign out any existing session before logging in
        if self.token:
            try:
                headers = {"Authorization": f"Bearer {self.token}"}
                body = {"type": "subscription", "session": self.session_id}
                requests.post(f"{self.base}/signout", headers=headers, json=body, timeout=30)
            except Exception:
                pass
            self.token = ""
            self.session_id = ""

        try:
            response = requests.post(url, json=payload, timeout=30)

            # Handle stuck sessions — retry up to 3 times
            if response.status_code == 403:
                import time as _time

                for attempt in range(3):
                    result = response.json()
                    sessions = result.get("data", {}).get("sessions", [])

                    if not sessions:
                        break

                    for session in sessions:
                        old_token = session.get("key", "")
                        session_id = session.get("id", "")
                        if old_token:
                            try:
                                headers = {"Authorization": f"Bearer {old_token}"}
                                body = {"type": "subscription", "session": session_id}
                                requests.post(f"{self.base}/signout", headers=headers, json=body, timeout=30)
                            except Exception:
                                pass

                    _time.sleep(2)
                    response = requests.post(url, json=payload, timeout=30)

                    if response.status_code != 403:
                        break

                if response.status_code != 200:
                    return {"success": False, "error": response.json().get("message", "Login failed after clearing sessions")}

            response.raise_for_status()
            result = response.json()

            if result.get("token"):
                self.token = result["token"]
                self.mid = result.get("mid", "")
                self.subscriptions = result.get("subscriptions", [])

                if self.subscriptions:
                    self.product_id = self.subscriptions[0].get("product_id", "")
                    self.session_id = str(self.subscriptions[0].get("subscription_id", ""))

                self.save_stored_data()

                return {
                    "success": True,
                    "subscriptions": self.subscriptions
                }
            else:
                return {
                    "success": False,
                    "error": result.get("message", "Login failed")
                }

        except Exception as e:
            return {"success": False, "error": str(e)}

    # -------------------------
    # SESSION-EXPIRY DETECTION
    # -------------------------
    def _is_session_expired_response(self, response):
        """True if a response indicates an expired/invalid auth session."""
        try:
            if response.status_code not in (401, 403):
                return False
            if response.status_code == 401:
                return True
            body = response.json()
            code = str(body.get("code", "")).lower()
            return any(k in code for k in ("session", "jwt", "token", "expired"))
        except Exception:
            return response.status_code == 401

    def clear_local_session(self):
        """Clear local session state (no server call) -- for expired/invalid sessions."""
        self.token = ""
        self.session_id = ""
        self.product_id = ""
        self.subscriptions = []
        self.save_stored_data()

    # -------------------------
    # CHECK CREDITS
    # -------------------------
    def available_credits(self):
        if not self.token or not self.product_id:
            return {"success": False, "error": "Not authenticated"}

        url = f"{self.base}/available/credits"
        headers = {"Authorization": f"Bearer {self.token}"}
        payload = {"product_id": self.product_id}

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            if self._is_session_expired_response(response):
                return {"success": False, "session_expired": True,
                        "error": "Your session has ended. Please log in again."}
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # -------------------------
    # CONSUME CREDITS
    # -------------------------
    def consume_credits(self, time_str):
        """
        time_str must be HH:MM:SS
        """
        if not self.token or not self.product_id:
            return {"success": False, "error": "Not authenticated"}

        url = f"{self.base}/consume-credits"
        headers = {"Authorization": f"Bearer {self.token}"}
        payload = {
            "product_id": self.product_id,
            "time": time_str
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            if self._is_session_expired_response(response):
                return {"success": False, "session_expired": True,
                        "error": "Your session has ended. Please log in again."}
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # -------------------------
    # VALIDATE TOKEN
    # -------------------------
    def validate_token(self):
        if not self.token:
            return {"success": False, "error": "No token stored"}

        url = f"{self.base}/token/validate"
        headers = {"Authorization": f"Bearer {self.token}"}

        try:
            response = requests.post(url, headers=headers, timeout=30)
            if self._is_session_expired_response(response):
                return {"success": False, "session_expired": True, "error": "Session expired"}
            if response.status_code == 200:
                return {"success": True}
            else:
                return {"success": False, "error": "Token invalid"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # -------------------------
    # GET USER INFO
    # -------------------------
    def get_user_info(self):
        if not self.token:
            return {"success": False, "error": "No token stored"}

        url = f"{self.base}/token/validate/info"
        headers = {"Authorization": f"Bearer {self.token}"}

        try:
            response = requests.post(url, headers=headers, timeout=30)
            if self._is_session_expired_response(response):
                return {"success": False, "session_expired": True, "error": "Session expired"}
            if response.status_code == 200:
                result = response.json()
                return {"success": True, "data": result.get("data", {})}
            else:
                return {"success": False, "error": "Could not fetch user info"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # -------------------------
    # LOGOUT
    # -------------------------
    def signout(self):
        if self.token:
            try:
                url = f"{self.base}/signout"
                headers = {"Authorization": f"Bearer {self.token}"}
                body = {"type": "subscription", "session": self.session_id}
                requests.post(url, headers=headers, json=body, timeout=30)
            except Exception:
                pass

        self.token = ""
        self.mid = ""
        self.product_id = ""
        self.session_id = ""
        self.subscriptions = []
        self.save_stored_data()
        return {"success": True}


auth_service = AuthService()