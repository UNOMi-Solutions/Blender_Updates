# Global in-memory state shared across modules
USER = {
    "name": "Guest",
    "status": "Trial",
}



