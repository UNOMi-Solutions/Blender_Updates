# Constants used in the add on
# The 14 phonemes as key, letters tuples
PHONEMES = [
    ("01", "O"),
    ("02", "A,E,I"),
    ("03", "Ee"),
    ("04", "Oo"),
    ("05", "C,D,G,K"),
    ("06", "B,M,P"),
    ("07", "F,V"),
    ("08", "Th"),
    ("09", "Q,W"),
    ("10", "Ch,J,Sh"),
    ("11", "R"),
    ("12", "L"),
    ("13", "Uh"),
    ("14", "Silent"),
]



