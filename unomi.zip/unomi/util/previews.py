# Preview icon loader for the panel
# Loads PNG/JPG files from `icons/` into a preview collection for the UI.
import os
import bpy
import bpy.utils.previews as previews

_icon_previews = None


def load_previews():
    # create (or reuse) a preview collection and load all icon images
    global _icon_previews
    if _icon_previews is not None:
        return _icon_previews
    _icon_previews = previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "..", "icons")
    icons_dir = os.path.abspath(icons_dir)
    if os.path.exists(icons_dir):
        for fname in os.listdir(icons_dir):
            if fname.lower().endswith((".png", ".jpg", ".jpeg")):
                key = os.path.splitext(fname)[0]
                _icon_previews.load(key, os.path.join(icons_dir, fname), 'IMAGE')
    return _icon_previews


def unload_previews():
    # free the preview collection so Blender can unload cleanly
    global _icon_previews
    if _icon_previews:
        previews.remove(_icon_previews)
        _icon_previews = None



