# Helpers to manage per-object phoneme mappings
# Store mappings as custom props on objects and sync with UI temp fields.
from .constants import PHONEMES


def get_object_phoneme_mapping(obj, phoneme_key):
    # read the mapping value (shape key name) from the object
    if not obj:
        return ""
    prop_name = f"unomi_map_{phoneme_key}"
    return obj.get(prop_name, "")


def set_object_phoneme_mapping(obj, phoneme_key, shape_key_name):
    # store the mapping value (shape key name) on the object
    if not obj:
        return
    prop_name = f"unomi_map_{phoneme_key}"
    obj[prop_name] = shape_key_name


def has_object_mappings(obj):
    # quick check: does this object have any phoneme mapping defined?
    if not obj:
        return False
    for key, _ in PHONEMES:
        if get_object_phoneme_mapping(obj, key):
            return True
    return False


def sync_temp_mappings_from_object(scene_props, obj):
    # copy mapping values from object into the UI temp fields
    if not obj:
        for key, _ in PHONEMES:
            setattr(scene_props, f"temp_map_{key}", "")
        return
    for key, _ in PHONEMES:
        mapping = get_object_phoneme_mapping(obj, key)
        setattr(scene_props, f"temp_map_{key}", mapping)


def sync_temp_mappings_to_object(scene_props, obj):
    # copy mapping values from UI temp fields back onto the object
    if not obj:
        return
    for key, _ in PHONEMES:
        temp_value = getattr(scene_props, f"temp_map_{key}", "")
        set_object_phoneme_mapping(obj, key, temp_value)


def update_temp_mapping(self, context, phoneme_key):
    # when a single UI temp field changes, immediately write it to the object
    s = context.scene.unomi
    if s.mapping_target_obj:
        temp_value = getattr(s, f"temp_map_{phoneme_key}", "")
        set_object_phoneme_mapping(s.mapping_target_obj, phoneme_key, temp_value)



