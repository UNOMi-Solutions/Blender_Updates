#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           1/20/26            Enhancements to auto update feature. Notifies user when to update and gets latest version.
#Jack Parent           1/30/26            Added multiple languages to lip sync.
#Jack Parent           3/01/26            Added Sync progress % display support.
#Jack Parent           3/01/26            Added token credit checks + consumption.
#Geanpierre Fernandez  7/31/26            Startup clears an expired session and shows Guest.

bl_info = {
    "name": "UNOMi",
    "author": "UNOMi",
    "version": (1, 5, 0),  # <--- go into menus.py and update the about version number to match this one.
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > UNOMi",
    "description": "UI with numbered icons (01–14) as big thumbnails",
    "category": "Animation",
}

import bpy
from .ops import mapping_ops, sync_ops, io_ops
from .ui import menus, panel
from .util.previews import load_previews, unload_previews
from .auth.service import auth_service
from .util.state import USER
from .ui.panel import UNOMI_PT_Extra
from . import addon_updater_ops
from . import addon_updater


def validate_startup_token():
    """Validate stored token and update in-memory USER state."""
    if auth_service and auth_service.token:
        result = auth_service.validate_token()
        if result.get('success'):
            user_info = auth_service.get_user_info()
            if user_info.get('success'):
                data = user_info.get('data', {})
                user_data = data.get('user', {})
                subscription = data.get('subscription', {})
                USER["name"] = user_data.get('email', 'Guest')
                USER["status"] = subscription.get('package', 'Free')
            else:
                USER["name"] = "Guest"
                USER["status"] = "Trial"
        else:
            # Token is invalid/expired — clear the local session.
            # No popup here: register() runs at startup without a reliable window
            # context; the panel simply shows Guest / the Login button.
            auth_service.clear_local_session()
            USER["name"] = "Guest"
            USER["status"] = "Trial"
    else:
        USER["name"] = "Guest"
        USER["status"] = "Trial"


def _unomi_check_updates_startup():
    try:
        addon_updater_ops.updater.check_for_update(now=True)
    except Exception:
        pass
    return None


def register():
    addon_updater_ops.register(bl_info)
    load_previews()

    # Register modules/classes
    mapping_ops.register()
    sync_ops.register()
    io_ops.register()
    menus.register()
    panel.register()

    # Single Scene pointer for all addon state (INCLUDING progress)
    bpy.types.Scene.unomi = bpy.props.PointerProperty(type=mapping_ops.UNOMiProps)

    bpy.utils.register_class(UNOMI_PT_Extra)

    validate_startup_token()
    bpy.app.timers.register(_unomi_check_updates_startup, first_interval=3.0)


def unregister():
    addon_updater_ops.unregister()

    # Schedule signout — only fires if Blender stays open (uninstall/disable)
    # If Blender is closing, this timer never executes, so session persists
    if auth_service and auth_service.token:
        def deferred_signout():
            try:
                auth_service.signout()
            except Exception:
                pass
            return None
        try:
            bpy.app.timers.register(deferred_signout, first_interval=0.5)
        except Exception:
            pass

    # Remove Scene props first
    if hasattr(bpy.types.Scene, "unomi"):
        del bpy.types.Scene.unomi

    # Unregister UI extras
    try:
        bpy.utils.unregister_class(UNOMI_PT_Extra)
    except Exception:
        pass

    # Unregister modules/classes
    panel.unregister()
    menus.unregister()
    io_ops.unregister()
    sync_ops.unregister()
    mapping_ops.unregister()

    unload_previews()