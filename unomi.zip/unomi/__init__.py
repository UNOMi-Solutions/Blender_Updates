# UNOMi Blender Add-on entry point
# Wires together subpackages (auth, ops, ui, util), registers classes,
# sets up Scene properties, loads icon previews, and validates stored token.
bl_info = {
    "name": "UNOMi",
    "author": "UNOMi",
    "version": (1, 3, 0),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > UNOMi",
    "description": "UI with numbered icons (01–14) as big thumbnails",
    "category": "Animation",
}

import bpy
from .ops import mapping_ops, sync_ops, io_ops
from .ui import menus, panel
from .util.previews import load_previews, unload_previews
from .auth.service import auth_service
from .util.state import USER
from .ui.panel import UNOMI_PT_Extra
from . import addon_updater_ops
from . import addon_updater


def validate_startup_token():
    """Validate stored token and update in-memory USER state.

    This keeps the UI coherent between Blender sessions without requiring
    the user to log in every time, while falling back to Guest/Trial on
    any validation failure.
    """
    if auth_service and auth_service.token:
        result = auth_service.validate_token()
        if result.get('success'):
            user_info = auth_service.get_user_info()
            if user_info.get('success'):
                data = user_info.get('data', {})
                user_data = data.get('user', {})
                subscription = data.get('subscription', {})
                USER["name"] = user_data.get('email', 'Guest')
                USER["status"] = subscription.get('package', 'Free')
            else:
                USER["name"] = "Guest"
                USER["status"] = "Trial"
        else:
            USER["name"] = "Guest"
            USER["status"] = "Trial"
    else:
        USER["name"] = "Guest"
        USER["status"] = "Trial"


def register():
    addon_updater_ops.register(bl_info)
    load_previews()
    mapping_ops.register()
    sync_ops.register()
    io_ops.register()
    menus.register()
    panel.register()
    bpy.types.Scene.unomi = bpy.props.PointerProperty(type=mapping_ops.UNOMiProps)
    bpy.utils.register_class(UNOMI_PT_Extra)
    validate_startup_token()


def unregister():
    addon_updater_ops.unregister()
    if hasattr(bpy.types.Scene, "unomi"):
        del bpy.types.Scene.unomi
    panel.unregister()
    menus.unregister()
    io_ops.unregister()
    sync_ops.unregister()
    mapping_ops.unregister()
    bpy.utils.unregister_class(UNOMI_PT_Extra)
    unload_previews()



