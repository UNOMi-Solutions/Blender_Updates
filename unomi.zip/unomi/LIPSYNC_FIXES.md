# Lipsync Module — Fixes

- Fixed English/Auto language failing (was sending requests to the wrong server address)
- Fixed sync freezing forever on errors with no explanation — now always shows a popup
- Fixed a successful credit charge sometimes being reported as failed
- Simplified the "not enough credits" message
- Increased account request timeouts (10s → 30s) for a slow server
- Fixed audio uploads mislabeling non-wav files
- Fixed "Clear Keyframes" crashing on Blender 5.x
- Fixed expired sessions showing a raw error instead of prompting re-login
- Fixed the Select button not refreshing the Target field in the panel
