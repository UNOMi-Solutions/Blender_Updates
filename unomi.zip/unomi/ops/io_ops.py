# Import/Export and housekeeping operators
# Export/import mappings/settings to JSON; clear/reset UI and keyframes.
import json
import bpy
from bpy_extras.io_utils import ExportHelper, ImportHelper

from ..util.constants import PHONEMES
from ..util.mapping import get_object_phoneme_mapping, set_object_phoneme_mapping


class UNOMI_OT_Clear(bpy.types.Operator):
    bl_idname = "unomi.clear"
    bl_label = "Clear"

    def execute(self, context):
        s = context.scene.unomi
        s.script_text = ""
        s.audio_path = ""
        s.strength = 50
        for key, _ in PHONEMES:
            setattr(s, f"temp_map_{key}", "")
        if s.mapping_target_obj:
            for key, _ in PHONEMES:
                set_object_phoneme_mapping(s.mapping_target_obj, key, "")
        self.report({'INFO'}, "Cleared fields")
        return {'FINISHED'}

class UNOMI_OT_ClearExpressions(bpy.types.Operator):
    bl_idname = "unomi.clear_expressions"
    bl_label = "Clear Expressions"

    def execute(self, context):
        s = context.scene.unomi

        string_props = [
            "target_obj_name",
            "left_brow_shape", "right_brow_shape",
            "left_brow_high_shape", "left_brow_low_shape",
            "right_brow_high_shape", "right_brow_low_shape",
            "left_eyelid_shape", "right_eyelid_shape",
            "left_eye_shape", "right_eye_shape",
            "left_cheek_shape", "right_cheek_shape",
            "left_nostril_shape", "right_nostril_shape",
            "left_ear_shape", "right_ear_shape",
            "mouth_shape",
        ]

        for p in string_props:
            setattr(s, p, "")

        float_props = [
            "left_brow_strength", "right_brow_strength",
            "eyelid_strength",
            "left_eye_strength", "right_eye_strength",
            "eye_jitter_amount",
            "left_cheek_strength", "right_cheek_strength",
            "cheek_physics_strength",
            "left_nostril_strength", "right_nostril_strength",
            "nostril_physics_strength",
            "left_ear_strength", "right_ear_strength",
            "ear_physics_strength",
            "mouth_strength", "mouth_physics_strength",
            "joy_strength", "sadness_strength", "anger_strength",
            "fear_strength", "surprise_strength", "disgust_strength",
            "contempt_strength", "neutral_strength", "laughter_strength",
            "curiosity_strength", "pride_strength", "confusion_strength",
            "embarrassment_strength", "determination_strength",
        ]

        for p in float_props:
            setattr(s, p, 50.0)

        bool_props = [
            "eyelid_blinks", "eyelid_random",
            "eye_jitter_enabled", "eye_jitter_x", "eye_jitter_y",
            "eye_jitter_xy", "eye_jitter_random",
            "cheek_physics", "nostril_physics",
            "ear_physics", "mouth_physics",
            "joy_enabled", "sadness_enabled", "anger_enabled",
            "fear_enabled", "surprise_enabled", "disgust_enabled",
            "contempt_enabled", "neutral_enabled", "laughter_enabled",
            "curiosity_enabled", "pride_enabled", "confusion_enabled",
            "embarrassment_enabled", "determination_enabled",
        ]

        for p in bool_props:
            setattr(s, p, False)

        return {'FINISHED'}


class UNOMI_OT_ExportConfig(bpy.types.Operator, ExportHelper):
    bl_idname = "unomi.export_config"
    bl_label = "Export Config"
    bl_description = "Export current settings to a JSON file"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".json"

    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        # collect mappings/settings and write them to a json file
        s = context.scene.unomi
        if s.use_multiple_objects:
            target_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not target_objects:
                target_objects = [s.target_obj] if s.target_obj else []
        else:
            target_objects = [s.target_obj] if s.target_obj else []
        if not target_objects:
            self.report({'ERROR'}, "No target objects selected")
            return {'CANCELLED'}

        all_models_data = {}
        for obj in target_objects:
            phoneme_mappings = {}
            for key, _ in PHONEMES:
                mapping = get_object_phoneme_mapping(obj, key)
                phoneme_mappings[key] = mapping if mapping else ""
            all_models_data[obj.name] = {"phoneme_mappings": phoneme_mappings}

        data = {
            "models": all_models_data,
            "audio": s.audio_path,
            "script": s.script_text,
            "intensity": s.strength,
        }
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            self.report({'INFO'}, f"Exported config to {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to export: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class UNOMI_OT_ImportConfig(bpy.types.Operator, ImportHelper):
    bl_idname = "unomi.import_config"
    bl_label = "Import Config"
    bl_description = "Import settings from a JSON file"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".json"

    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        # read json and apply mappings/settings back to the scene
        s = context.scene.unomi
        if s.use_multiple_objects:
            target_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not target_objects:
                target_objects = [s.target_obj] if s.target_obj else []
        else:
            target_objects = [s.target_obj] if s.target_obj else []
        if not target_objects:
            self.report({'ERROR'}, "No target objects selected")
            return {'CANCELLED'}

        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            models_data = data.get("models", {})
            for obj in target_objects:
                if obj.name in models_data:
                    phoneme_mappings = models_data[obj.name].get("phoneme_mappings", {})
                    for key, _ in PHONEMES:
                        if key in phoneme_mappings:
                            mapping_value = phoneme_mappings[key]
                            set_object_phoneme_mapping(obj, key, mapping_value)
                            if obj == target_objects[0]:
                                setattr(s, f"temp_map_{key}", mapping_value)
            s.audio_path = data.get("audio", "")
            s.script_text = data.get("script", "")
            s.strength = data.get("intensity", 50)
            self.report({'INFO'}, f"Imported config from {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class UNOMI_OT_ResetFields(bpy.types.Operator):
    bl_idname = "unomi.reset_fields"
    bl_label = "Reset Fields"
    bl_description = "Reset all input fields"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # reset inputs and mapping fields to defaults
        s = context.scene.unomi
        s.audio_path = ""
        s.script_text = ""
        s.strength = 50
        for key, _ in PHONEMES:
            setattr(s, f"temp_map_{key}", "")
        if s.mapping_target_obj:
            for key, _ in PHONEMES:
                set_object_phoneme_mapping(s.mapping_target_obj, key, "")
        self.report({'INFO'}, "Reset all fields")
        return {'FINISHED'}


class UNOMI_OT_ClearKeyframes(bpy.types.Operator):
    bl_idname = "unomi.clear_keyframes"
    bl_label = "Clear Keyframes"
    bl_description = "Clear animation keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # remove all shapekey keyframes for selected meshes (except Basis)
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH' and obj.data.shape_keys:
                for key in obj.data.shape_keys.key_blocks:
                    if key.name != "Basis":
                        key.value = 0.0
                if obj.data.shape_keys.animation_data:
                    if obj.data.shape_keys.animation_data.action:
                        for key in obj.data.shape_keys.key_blocks:
                            if key.name != "Basis":
                                fcurves = obj.data.shape_keys.animation_data.action.fcurves
                                for fcurve in fcurves:
                                    if fcurve.data_path == f'key_blocks["{key.name}"].value':
                                        fcurve.keyframe_points.clear()
        self.report({'INFO'}, "Cleared keyframes")
        return {'FINISHED'}


classes = (
    UNOMI_OT_Clear,
    UNOMI_OT_ExportConfig,
    UNOMI_OT_ImportConfig,
    UNOMI_OT_ResetFields,
    UNOMI_OT_ClearKeyframes,
    UNOMI_OT_ClearExpressions,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass



