#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           1/20/26            Enhancements to auto update feature. Notifies user when to update and gets latest version.
#Jack Parent           1/30/26            Added multiple languages to lip sync.
#Jack Parent           3/01/26            Added Sync progress % display support.
#Jack Parent           3/01/26            Added token credit checks + consumption.
#Geanpierre Fernandez  7/29/26            Fixed English/Auto endpoint routing (root vs "/align").
#Geanpierre Fernandez  7/29/26            Added pre-send credit gate (blocks sync when credits insufficient).
#Geanpierre Fernandez  7/31/26            Expired session: prompt re-login instead of a raw 403.
#Geanpierre Fernandez  7/31/26            Trial/Free cap matches plan case-insensitively.
#Geanpierre Fernandez  7/31/26            Tolerant credit-balance parsing.
#Geanpierre Fernandez  7/31/26            Audio upload uses its real MIME type.
#Geanpierre Fernandez  7/31/26            Sync errors: one popup + setup validation before credit check.
#Abdullah Almesri      8/3/26             Keyframes offset by sync_start_frame instead of always starting at frame 1.
#Abdullah Almesri      8/3/26             Progress bar paced per-language instead of a flat tick rate.
#Abdullah Almesri      8/3/26             Fixed EN pacing (14->7s) and progress bar now resets to 0 at wait start.
#Geanpierre Fernandez  8/4/26             Fixed sync freezing/silent on completion (deferred callbacks called self.report() after execute() had returned).
#Geanpierre Fernandez  8/4/26             Simplified the insufficient-credits message (no more raw numbers/estimates).
#Geanpierre Fernandez  8/4/26             Fixed a successful credit charge being reported as failed (checked the wrong response fields).

import os
import math
import threading
import requests
import bpy
import time

from ..util.constants import PHONEMES
from ..util.mapping import get_object_phoneme_mapping, has_object_mappings
from ..util.state import USER
from ..auth.service import auth_service


def _tag_redraw_all():
    wm = bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()


def _schedule_ui_refresh():
    """Force UI regions to repaint shortly after a state change.

    Changing a plain Python global (e.g. USER) does not notify Blender, so the panel
    can show a stale Login/Logout button until the user interacts with it. A one-shot
    timer reliably repaints every area (same mechanism the sync progress bar uses).
    """
    def _redraw():
        try:
            for win in bpy.context.window_manager.windows:
                for area in win.screen.areas:
                    area.tag_redraw()
        except Exception:
            pass
        return None
    try:
        bpy.app.timers.register(_redraw, first_interval=0.05)
    except Exception:
        pass


def _seconds_to_hhmmss(seconds: float) -> str:
    sec = int(max(0, round(seconds)))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def _parse_credits_seconds(value) -> int:
    """
    Parse a credit balance into whole seconds, tolerant of formats.

    The old inline parser assumed exactly "HH:MM:SS" and any other shape threw, was
    swallowed, and became 0 -> a false "No credits remaining". This accepts:
      - "HH:MM:SS", "H:MM:SS", "MM:SS", "SS" (any count of colon-separated parts)
      - a plain number of seconds ("45", 45, 45.0)
    and returns 0 on anything unparseable.
    """
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        return max(0, int(value))
    s = str(value).strip()
    if not s:
        return 0
    try:
        if ":" in s:
            total = 0.0
            for part in s.split(":"):
                total = total * 60 + float(part)
            return max(0, int(total))
        return max(0, int(float(s)))
    except Exception:
        return 0


# The original/default English phoneme service exposes its alignment endpoint at the
# ROOT path; the newer per-language services expose it at "/align". See build_align_url().
DEFAULT_SERVICE_URL = "https://lip-sync-phoneme-finder-konujgly4q-wl.a.run.app/"


def resolve_service_url(lang_code: str) -> str:
    LANG_URLS = {
        "default": DEFAULT_SERVICE_URL,
        "it": "https://unomi-it-663811464633.us-west2.run.app/",
        "zh": "https://unomi-zh-663811464633.us-west2.run.app/",
        "ru": "https://unomi-ru-663811464633.us-west2.run.app/",
        "de": "https://unomi-de-663811464633.us-west2.run.app/",
        "es": "https://unomi-es-663811464633.us-west2.run.app/",
        "fr": "https://unomi-fr-663811464633.us-west2.run.app/",
        "jp": "https://unomi-jp-663811464633.us-west2.run.app/",
        #"ja": "https://unomi-jp-663811464633.us-west2.run.app/",
        "pt": "https://unomi-pt-663811464633.us-west2.run.app/",
    }

    code = (lang_code or "auto").strip().lower()
    if code in ("", "auto"):
        return LANG_URLS["default"]
    return LANG_URLS.get(code, LANG_URLS["default"])


def build_align_url(service_url: str) -> str:
    """English/default serves alignment at its root path; other languages use "/align"."""
    base = (service_url or "").strip().rstrip("/")
    if base == DEFAULT_SERVICE_URL.rstrip("/"):
        return base + "/"        # English/default: POST to the root endpoint
    return base + "/align"       # per-language services expose "/align"


# ---------------------------------------------------------------------------
# Pre-flight credit estimate: exact Cloud Run processing time isn't known until
# after the request, so cost is estimated from audio duration + a per-language
# rate, and that much must be held before sending. Constants below are tunable.
# ---------------------------------------------------------------------------
CREDIT_DEFAULT_RATE = 1.5       # processing-seconds charged per audio-second (warm + buffer)
CREDIT_LANG_RATE = {
    "ru": 3.0,                  # Russian: premium special case (heavy / slow service)
}
CREDIT_BASE_OVERHEAD_SEC = 3.0  # small fixed per-call cost
CREDIT_SAFETY_MARGIN = 0.15     # extra headroom so users aren't under-gated


# ---------------------------------------------------------------------------
# Progress bar pacing
# ---------------------------------------------------------------------------
# The phoneme service gives no real progress mid-request, so we fake a smooth climb
# toward 95% based on each language's typical processing time. Unknown languages fall
# back to SYNC_DURATION_FALLBACK_SEC.
SYNC_DURATION_SEC = {
    "en": 7,
    "es": 79,
    "pt": 63,
    "fr": 68,
    "de": 75,
    "it": 67,
    "zh": 83,
    "jp": 90,
    "ru": 90,
}
SYNC_DURATION_FALLBACK_SEC = 75


def estimate_cost_seconds(audio_seconds: float, lang: str) -> int:
    """Estimated credit cost (whole seconds) to sync a clip of the given length/language."""
    rate = CREDIT_LANG_RATE.get((lang or "").strip().lower(), CREDIT_DEFAULT_RATE)
    raw = audio_seconds * rate + CREDIT_BASE_OVERHEAD_SEC
    return int(math.ceil(raw * (1.0 + CREDIT_SAFETY_MARGIN)))


def _audio_duration_seconds(path: str) -> float:
    """Best-effort audio length in seconds: aud (broad formats) -> wave (wav only)."""
    try:
        import aud
        snd = aud.Sound(path)
        specs = snd.specs
        rate = specs[0] if specs else 0
        if rate:
            return float(snd.length) / float(rate)
    except Exception:
        pass
    try:
        import wave
        with wave.open(path, 'r') as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return 0.0


class UNOMI_OT_Sync(bpy.types.Operator):
    bl_idname = "unomi.sync"
    bl_label = "Sync"
    bl_options = {'REGISTER', 'UNDO'}

    # -----------------------------
    # Progress heartbeat
    # -----------------------------
    def progress_heartbeat_timer(self):
        """
        Ensures the % keeps moving while syncing so the UI never looks frozen.

        - While waiting on Cloud Run: nudges progress up to 95%.
        - While applying keyframes: nudges progress up to 99%.
        - 100% is reserved ONLY for true completion.
        """
        u = getattr(bpy.context.scene, "unomi", None)
        if not u or not getattr(u, "is_syncing", False):
            return None  # stop timer

        now = time.monotonic()
        last = float(getattr(u, "last_progress_tick", 0.0))
        cur = int(getattr(u, "sync_progress", 0))

        if now - last >= 0.2:
            waiting = bool(getattr(u, "sync_waiting_response", False))
            if waiting:
                started = getattr(self, "_sync_started_at", None)
                if started is not None:
                    duration = getattr(self, "_sync_duration", None) or SYNC_DURATION_FALLBACK_SEC
                    elapsed = now - started
                    pct = int(min(95, (elapsed / duration) * 95))
                    if pct > cur:
                        u.sync_progress = pct
                        u.last_progress_tick = now
                elif cur < 95:
                    u.sync_progress = cur + 1
                    u.last_progress_tick = now
            else:
                if cur < 99:
                    u.sync_progress = cur + 1
                    u.last_progress_tick = now

            _tag_redraw_all()

        return 0.1

    # -----------------------------
    # Helpers
    # -----------------------------
    def _set_output(self, ok: bool, msg: str):
        u = getattr(bpy.context.scene, "unomi", None)
        if u:
            if hasattr(u, "last_sync_ok"):
                u.last_sync_ok = bool(ok)
            if hasattr(u, "last_sync_output"):
                u.last_sync_output = str(msg)
        _tag_redraw_all()

    def _reset_state(self, progress_to_zero: bool = True):
        u = getattr(bpy.context.scene, "unomi", None)
        if u:
            u.is_syncing = False
            u.sync_waiting_response = False
            if progress_to_zero:
                u.sync_progress = 0
            if hasattr(u, "last_progress_tick"):
                u.last_progress_tick = time.monotonic()
        _tag_redraw_all()

    def _popup_message(self, context, title, message, icon='ERROR'):
        """Best-effort blocking popup box (in addition to the status-bar report).

        Safe to call from deferred bpy.app.timers callbacks (pass bpy.context) -
        unlike self.report(), which silently no-ops once execute() has returned.
        """
        def _draw(menu, ctx):
            col = menu.layout.column(align=True)
            for part in message.replace(". ", ".\n").split("\n"):
                part = part.strip()
                if part:
                    col.label(text=part)
        try:
            context.window_manager.popup_menu(_draw, title=title, icon=icon)
        except Exception:
            pass

    def _fail(self, context, message, title="UNOMi - Cannot Sync"):
        """Show a single popup error, reset sync state, and cancel the operator.

        Uses one message (the popup) only -- no extra self.report -- so the user never
        sees the same error twice.
        """
        self._popup_message(context, title, message)
        self._reset_state(progress_to_zero=True)
        return {'CANCELLED'}

    def _handle_session_expired(self, context):
        """Clear the dead local session, reset to Guest, and prompt re-login."""
        try:
            auth_service.token = ""
            auth_service.session_id = ""
            auth_service.save_stored_data()
        except Exception:
            pass
        USER["name"] = "Guest"
        USER["status"] = "Trial"

        def _draw(menu, ctx):
            col = menu.layout.column(align=True)
            col.label(text="Your UNOMi session has ended.")
            col.label(text="Please log in again to continue.")
        try:
            context.window_manager.popup_menu(_draw, title="Session Ended", icon='ERROR')
        except Exception:
            pass
        _tag_redraw_all()
        _schedule_ui_refresh()   # ensure the panel repaints to show the Login button

    def _require_login_and_sufficient_credits(self, audio_abs, lang) -> (bool, str, str):
        """
        Pre-send credit gate. Returns (ok, error_message, remaining_time_formatted).

        Blocks the sync BEFORE anything is sent to the cloud unless the user holds enough
        credits to cover this clip's ESTIMATED cost -- not merely > 0 (which previously let
        a user with any tiny balance run an unlimited-length sync). See estimate_cost_seconds().
        """
        if not getattr(auth_service, "token", "") or not getattr(auth_service, "product_id", ""):
            return False, "Please Login before syncing.", ""

        res = auth_service.available_credits()
        if isinstance(res, dict) and res.get("session_expired"):
            return False, "__SESSION_EXPIRED__", ""
        if not res or res.get("status") != "success":
            err = res.get("message") or res.get("error") or "Unable to check credits."
            return False, f"Credits check failed: {err}", ""

        remaining_fmt = res.get("available_credits", "")
        remaining_seconds = _parse_credits_seconds(remaining_fmt)  # tolerant parsing

        audio_seconds = _audio_duration_seconds(audio_abs)
        if audio_seconds <= 0:
            # Couldn't read the audio length -> fall back to the old "must have some" gate
            if remaining_seconds <= 0:
                return False, "No credits remaining.", remaining_fmt
            return True, "", remaining_fmt

        needed = estimate_cost_seconds(audio_seconds, lang)
        if remaining_seconds < needed:
            return False, "You do not have enough credits for this lip sync.", remaining_fmt

        return True, "", remaining_fmt

    # -----------------------------
    # Execute (main thread)
    # -----------------------------
    def execute(self, context):
        s = getattr(context.scene, "unomi", None)
        if not s:
            return self._fail(context, "UNOMi properties not registered (Scene.unomi missing).")

        # Initialize sync state
        s.is_syncing = True
        s.sync_progress = 0
        s.sync_waiting_response = False
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()

        # Clear last output at start
        self._set_output(ok=False, msg="")

        # Start heartbeat
        bpy.app.timers.register(self.progress_heartbeat_timer)

        # -----------------------------
        # Validation (0 -> 10)
        # Order: account first (must be logged in), then mesh setup top-to-bottom
        # (target -> shape keys -> mappings), then inputs (audio, script), then the
        # credit check. Each failure shows exactly ONE popup (via _fail).
        # -----------------------------
        if not getattr(auth_service, "token", "") or not getattr(auth_service, "product_id", ""):
            return self._fail(context, "Please log in before syncing.")

        if s.use_multiple_objects:
            target_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not target_objects:
                return self._fail(context, "No mesh objects selected. Select the mesh(es) to lip-sync.")
            if not s.target_obj:
                return self._fail(context, "No primary target set. Pick a Target object for the shape-key reference.")
        else:
            if not s.target_obj:
                return self._fail(context, "No target object selected. Pick a Target object.")
            target_objects = [s.target_obj]

        # Mesh setup: shape keys must exist, and phoneme slots must be mapped -- report
        # these BEFORE the credit check so the user fixes the actual setup first.
        no_shape_keys = [o.name for o in target_objects
                         if not (o.type == 'MESH' and o.data.shape_keys)]
        if no_shape_keys:
            return self._fail(context,
                "No shape keys on: " + ", ".join(no_shape_keys) +
                ". Add mouth shape keys to the mesh before syncing.")

        unmapped = [o.name for o in target_objects if not has_object_mappings(o)]
        if unmapped:
            return self._fail(context,
                "No phoneme mappings assigned for: " + ", ".join(unmapped) +
                ". Map your mouth shapes to the phoneme slots (O, A/E/I, Ee, ...) before syncing.")

        audio_abs = bpy.path.abspath(s.audio_path) if getattr(s, "audio_path", "") else ""
        if not audio_abs or not os.path.isfile(audio_abs):
            return self._fail(context, "Audio file not set or not found. Choose an audio file.")

        script_text = (getattr(s, "script_text", "") or "").strip()
        if not script_text:
            return self._fail(context, "Script text is empty. Paste the script/transcript.")

        # Language is needed for the credit estimate (per-language rate)
        lang = (getattr(s, "language", "auto") or "auto").lower()

        # Credits pre-check: require ENOUGH for this clip's estimated cost, not just > 0.
        # Blocks (with a single popup) before anything is sent, so the sync never applies
        # when the user can't afford it.
        ok, err, remaining_fmt = self._require_login_and_sufficient_credits(audio_abs, lang)
        if not ok:
            if err == "__SESSION_EXPIRED__":
                self._handle_session_expired(context)
                self._reset_state(progress_to_zero=True)
                return {'CANCELLED'}
            return self._fail(context, err)

        s.sync_progress = 10
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()
        _tag_redraw_all()

        # -----------------------------
        # Mapping build (10 -> 25)
        # -----------------------------
        target_object_names = [obj.name for obj in target_objects]
        mappings_by_objname = {}

        total_maps = max(1, len(target_objects) * len(PHONEMES))
        done_maps = 0

        for obj in target_objects:
            per_obj = {}
            for key, _ in PHONEMES:
                per_obj[key] = get_object_phoneme_mapping(obj, key)
                done_maps += 1
                s.sync_progress = 10 + int((done_maps / total_maps) * 15)
                if hasattr(s, "last_progress_tick"):
                    s.last_progress_tick = time.monotonic()
            mappings_by_objname[obj.name] = per_obj

        s.sync_progress = 25
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()
        _tag_redraw_all()

        # Prepare service request
        fps = bpy.context.scene.render.fps
        strength = getattr(s, "strength", 50)

        service_url = resolve_service_url(lang)

        # pace the heartbeat's climb toward 95% using this language's typical duration
        self._sync_started_at = time.monotonic()
        self._sync_duration = SYNC_DURATION_SEC.get(lang, SYNC_DURATION_FALLBACK_SEC)

        # Waiting phase
        s.sync_waiting_response = True
        s.sync_progress = 0
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()

        if remaining_fmt:
            self.report({'INFO'}, f"Syncing ({lang})... Credits: {remaining_fmt}")
        else:
            self.report({'INFO'}, f"Syncing ({lang})...")

        # Run request in background thread
        thread = threading.Thread(
            target=self._sync_thread,
            args=(
                target_object_names,
                mappings_by_objname,
                fps,
                strength,
                audio_abs,
                script_text,
                service_url,
                lang,
            ),
        )
        thread.daemon = True
        thread.start()

        return {'FINISHED'}

    # -----------------------------
    # Background thread
    # -----------------------------
    def _sync_thread(
        self,
        target_object_names,
        mappings_by_objname,
        fps,
        strength,
        audio_abs,
        script_text,
        service_url,
        lang,
    ):
        try:
            # pick the correct endpoint per service (English=root, others=/align)
            url = build_align_url(service_url)

            # Measure Cloud Run processing time accurately (wall-clock)
            server_start = time.monotonic()

            # label the upload with a standard audio MIME type by extension (was
            # hard-coded "audio/wav", which mislabels .mp3/.m4a/.ogg). Unknown extensions
            # fall back to "audio/wav" -- the server has accepted that for every format so
            # far, so the fallback stays on known-good behavior.
            _AUDIO_MIME = {
                ".wav": "audio/wav", ".mp3": "audio/mpeg", ".m4a": "audio/mp4",
                ".aac": "audio/aac", ".ogg": "audio/ogg", ".oga": "audio/ogg",
                ".flac": "audio/flac", ".opus": "audio/opus", ".webm": "audio/webm",
            }
            audio_mime = _AUDIO_MIME.get(os.path.splitext(audio_abs)[1].lower(), "audio/wav")

            with open(audio_abs, "rb") as audio_fh:
                files = {
                    "text": ("text.txt", script_text.encode("utf-8"), "text/plain"),
                    "audio": (os.path.basename(audio_abs), audio_fh, audio_mime),
                }
                resp = requests.post(url, files=files, timeout=3600)

            server_elapsed = max(1.0, time.monotonic() - server_start)

            resp.raise_for_status()
            data = resp.json()
            phones = data.get("phonesTimes", [])

            # We'll charge credits ONLY after apply succeeds.
            apply_done = threading.Event()
            apply_result = {"ok": False, "msg": ""}

            # Mark response received (main thread)
            def mark_response_received():
                u = getattr(bpy.context.scene, "unomi", None)
                if u:
                    u.sync_waiting_response = False
                    u.sync_progress = 100
                    if hasattr(u, "last_progress_tick"):
                        u.last_progress_tick = time.monotonic()
                _tag_redraw_all()
                return None

            bpy.app.timers.register(mark_response_received, first_interval=0.0)

            # Apply keyframes (main thread)
            def apply_on_main():
                try:
                    scene = bpy.context.scene
                    s = getattr(scene, "unomi", None)
                    if not s:
                        apply_result["ok"] = False
                        apply_result["msg"] = "Sync failed X | Scene.unomi missing"
                        return None

                    target_objects = []
                    for name in target_object_names:
                        obj = bpy.data.objects.get(name)
                        if obj and obj.type == 'MESH':
                            target_objects.append(obj)

                    if not target_objects:
                        apply_result["ok"] = False
                        apply_result["msg"] = "Sync failed X | No target objects resolved"
                        return None

                    for obj in target_objects:
                        if not obj.data.shape_keys:
                            apply_result["ok"] = False
                            apply_result["msg"] = f"Sync failed X | {obj.name} has no shape keys"
                            return None

                    # Zero at the sync start frame
                    s.sync_progress = max(int(getattr(s, "sync_progress", 0)), 95)
                    if hasattr(s, "last_progress_tick"):
                        s.last_progress_tick = time.monotonic()

                    # shift the whole timeline so it starts at sync_start_frame instead of frame 1
                    frame_offset = int(getattr(s, "sync_start_frame", 1)) - 1

                    for obj in target_objects:
                        per_obj = mappings_by_objname.get(obj.name, {})
                        for key, _label in PHONEMES:
                            mapped = (per_obj.get(key) or "").strip()
                            if mapped and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=frame_offset)

                    # Trial/Free cap in animation application.
                    # match case-insensitively so plan strings like "free"/"FREE" are still
                    # recognized. Unknown/paid statuses are treated as paid (not capped) so real
                    # customers are never wrongly truncated; a missing status defaults to capped.
                    try:
                        status_norm = str(USER.get("status", "Trial")).strip().lower()
                        is_trial_or_free = status_norm in ("trial", "free")
                    except Exception:
                        is_trial_or_free = True

                    filtered_phones = phones
                    if is_trial_or_free:
                        CAP_SECONDS = 30.0
                        try:
                            filtered_phones = [
                                p for p in phones
                                if float(p.get("start_phone", 0.0)) <= CAP_SECONDS
                            ]
                        except Exception:
                            filtered_phones = phones

                    total = max(1, len(filtered_phones))

                    for i, p in enumerate(filtered_phones):
                        cluster = p.get("cluster", "")
                        try:
                            start = float(p.get("start_phone", 0.0))
                        except Exception:
                            start = 0.0
                        try:
                            end = float(p.get("end_phone", start))
                        except Exception:
                            end = start

                        cluster_num = cluster.replace("clu", "").zfill(2)

                        start_f = int(start * fps) + frame_offset
                        if i + 1 < len(phones):
                            try:
                                end_time = float(phones[i + 1].get("start_phone", end))
                            except Exception:
                                end_time = end
                        else:
                            end_time = end
                        end_f = int(end_time * fps) + frame_offset

                        if i > 0:
                            prev_phone = phones[i - 1]
                            try:
                                duration = start - float(prev_phone.get("start_phone", start))
                            except Exception:
                                duration = 0.0

                            if prev_phone.get("cluster") == "clu14" and duration > 0.2:
                                pre_start = start - 0.2
                            elif prev_phone.get("cluster") != cluster and duration > 0.4:
                                pre_start = start - 0.4
                            else:
                                try:
                                    pre_start = float(prev_phone.get("start_phone", start))
                                except Exception:
                                    pre_start = start
                        else:
                            pre_start = start - 0.2

                        pre_start_f = int(pre_start * fps) + frame_offset

                        min_duration_frames = 2
                        if end_f - start_f < min_duration_frames:
                            end_f = start_f + min_duration_frames
                        if start_f - pre_start_f < min_duration_frames:
                            pre_start_f = start_f - min_duration_frames

                        max_value = max(0.0, min(1.0, strength / 100.0))

                        for obj in target_objects:
                            per_obj = mappings_by_objname.get(obj.name, {})
                            mapped = (per_obj.get(cluster_num) or "").strip()
                            if mapped and obj.data.shape_keys and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=pre_start_f)
                                kb.value = max_value
                                kb.keyframe_insert("value", frame=start_f)
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=end_f)

                        real_pct = 95 + int(((i + 1) / total) * 4)  # 95->99
                        s.sync_progress = max(int(getattr(s, "sync_progress", 0)), min(99, real_pct))
                        if hasattr(s, "last_progress_tick"):
                            s.last_progress_tick = time.monotonic()
                        _tag_redraw_all()

                    apply_result["ok"] = True
                    apply_result["msg"] = f"Sync complete ✅ | Lang: {lang.upper()} | Phones: {len(filtered_phones)} | Objects: {len(target_objects)}"
                    return None

                finally:
                    u = getattr(bpy.context.scene, "unomi", None)
                    if u:
                        u.is_syncing = False
                        u.sync_waiting_response = False
                        if hasattr(u, "last_progress_tick"):
                            u.last_progress_tick = time.monotonic()
                    _tag_redraw_all()
                    apply_done.set()

            bpy.app.timers.register(apply_on_main, first_interval=0.0)

            # Wait until apply finishes
            apply_done.wait(timeout=600.0)

            if not apply_result["ok"]:
                def fail_msg():
                    self._set_output(False, apply_result["msg"])
                    self._popup_message(bpy.context, "UNOMi - Sync Failed", apply_result["msg"])
                    self._reset_state(progress_to_zero=True)
                    return None
                bpy.app.timers.register(fail_msg, first_interval=0.0)
                return

            # Consume credits based on server processing time
            charge_hhmmss = _seconds_to_hhmmss(server_elapsed)
            consume_res = auth_service.consume_credits(charge_hhmmss)

            # the session can die between the pre-check and this charge.
            session_expired = isinstance(consume_res, dict) and consume_res.get("session_expired")

            final_msg = apply_result["msg"] + f" | Charged: {charge_hhmmss}"

            if consume_res and consume_res.get("status") == "success":
                remaining_fmt = consume_res.get("remaining_time", "")
                if remaining_fmt:
                    final_msg += f" | Credits left: {remaining_fmt}"
                else:
                    final_msg += " | Credits updated"
            elif session_expired:
                final_msg += " | Session ended before charging - please log in again"
                # Surface the same clean re-login prompt + log out (on the main thread)
                def _session_expired_main():
                    self._handle_session_expired(bpy.context)
                    return None
                bpy.app.timers.register(_session_expired_main, first_interval=0.0)
            else:
                err = ""
                if isinstance(consume_res, dict):
                    err = consume_res.get("message") or consume_res.get("error") or ""
                final_msg += f" | Credit charge failed{(': ' + err) if err else ''}"

            def done_msg():
                s = getattr(bpy.context.scene, "unomi", None)
                if s:
                    s.sync_progress = 100
                    if hasattr(s, "last_progress_tick"):
                        s.last_progress_tick = time.monotonic()
                self._set_output(True, final_msg)
                self._popup_message(bpy.context, "UNOMi - Sync Complete", final_msg, icon='INFO')
                _tag_redraw_all()
                return None

            bpy.app.timers.register(done_msg, first_interval=0.0)

        except Exception as e:
            # Capture the message now - `e` is deleted once this except block exits,
            # and the timer callback below only runs later on the main thread.
            err_str = str(e)
            print("Sync thread failed:", err_str)

            def reset_fail():
                self._set_output(False, f"Sync failed X | {err_str}")
                self._popup_message(bpy.context, "UNOMi - Sync Failed", f"Sync failed: {err_str}")
                self._reset_state(progress_to_zero=True)
                return None

            bpy.app.timers.register(reset_fail, first_interval=0.0)


classes = (UNOMI_OT_Sync,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass