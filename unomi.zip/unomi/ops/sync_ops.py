# Lip sync synchronization operator
# Sends text/audio to service in a background thread and applies keyframes
# on Blender's main thread. Respects the Trial/Free 30s cap.
import os
import threading
import requests
import bpy

from ..util.constants import PHONEMES
from ..util.mapping import get_object_phoneme_mapping
from ..util.state import USER


class UNOMI_OT_Sync(bpy.types.Operator):
    bl_idname = "unomi.sync"
    bl_label = "Sync"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # validate inputs and spin up the background network request
        s = context.scene.unomi
        if s.use_multiple_objects:
            target_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not target_objects:
                self.report({'ERROR'}, "No mesh objects selected")
                return {'CANCELLED'}
            if not s.target_obj:
                self.report({'ERROR'}, "Primary target object needed for shape key reference")
                return {'CANCELLED'}
        else:
            if not s.target_obj:
                self.report({'ERROR'}, "No target object selected")
                return {'CANCELLED'}
            target_objects = [s.target_obj]

        audio_abs = bpy.path.abspath(s.audio_path) if s.audio_path else ""
        if not audio_abs or not os.path.isfile(audio_abs):
            self.report({'ERROR'}, "Audio file not set or not found")
            return {'CANCELLED'}
        script_text = s.script_text.strip()
        if not script_text:
            self.report({'ERROR'}, "Script text is empty")
            return {'CANCELLED'}

        target_object_names = [obj.name for obj in target_objects]
        mappings_by_objname = {}
        for obj in target_objects:
            per_obj = {}
            for key, _ in PHONEMES:
                per_obj[key] = get_object_phoneme_mapping(obj, key)
            mappings_by_objname[obj.name] = per_obj
        fps = bpy.context.scene.render.fps
        strength = s.strength

        s.is_syncing = True
        self.report({'INFO'}, "Syncing... Please wait")
        thread = threading.Thread(
            target=self._sync_thread,
            args=(target_object_names, mappings_by_objname, fps, strength, audio_abs, script_text),
        )
        thread.daemon = True
        thread.start()
        return {'FINISHED'}

    def _sync_thread(self, target_object_names, mappings_by_objname, fps, strength, audio_abs, script_text):
        # run the HTTP call and then schedule the main-thread keyframe work
        try:
            url = "https://lip-sync-phoneme-finder-konujgly4q-wl.a.run.app/"
            files = {
                "text": ("text.txt", script_text.encode("utf-8"), "text/plain"),
                "audio": (os.path.basename(audio_abs), open(audio_abs, "rb"), "audio/wav"),
            }
            resp = requests.post(url, files=files, timeout=120)
            files["audio"][1].close()
            resp.raise_for_status()
            data = resp.json()
            phones = data.get("phonesTimes", [])

            def apply_on_main():
                # insert all the shape key keyframes on Blender's main thread
                try:
                    target_objects = []
                    for name in target_object_names:
                        obj = bpy.data.objects.get(name)
                        if obj and obj.type == 'MESH':
                            target_objects.append(obj)
                    if not target_objects:
                        return None
                    for obj in target_objects:
                        if not obj.data.shape_keys:
                            return None

                    for obj in target_objects:
                        per_obj = mappings_by_objname.get(obj.name, {})
                        for key, _label in PHONEMES:
                            mapped = (per_obj.get(key) or "").strip()
                            if mapped and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=0)

                    try:
                        is_trial_or_free = str(USER.get("status", "Trial")) in ("Trial", "Free")
                    except Exception:
                        is_trial_or_free = True
                    filtered_phones = phones
                    if is_trial_or_free:
                        CAP_SECONDS = 30.0
                        try:
                            filtered_phones = [p for p in phones if float(p.get("start_phone", 0.0)) <= CAP_SECONDS]
                        except Exception:
                            filtered_phones = phones

                    for i, p in enumerate(filtered_phones):
                        cluster = p.get("cluster", "")
                        try:
                            start = float(p.get("start_phone", 0.0))
                        except Exception:
                            start = 0.0
                        try:
                            end = float(p.get("end_phone", start))
                        except Exception:
                            end = start
                        cluster_num = cluster.replace("clu", "").zfill(2)

                        start_f = int(start * fps)
                        if i + 1 < len(phones):
                            try:
                                end_time = float(phones[i + 1].get("start_phone", end))
                            except Exception:
                                end_time = end
                        else:
                            end_time = end
                        end_f = int(end_time * fps)

                        if i > 0:
                            prev_phone = phones[i - 1]
                            try:
                                duration = start - float(prev_phone.get("start_phone", start))
                            except Exception:
                                duration = 0.0
                            if prev_phone.get("cluster") == "clu14" and duration > 0.2:
                                pre_start = start - 0.2
                            elif prev_phone.get("cluster") != cluster and duration > 0.4:
                                pre_start = start - 0.4
                            else:
                                try:
                                    pre_start = float(prev_phone.get("start_phone", start))
                                except Exception:
                                    pre_start = start
                        else:
                            pre_start = start - 0.2
                        pre_start_f = int(pre_start * fps)

                        min_duration_frames = 2
                        if end_f - start_f < min_duration_frames:
                            end_f = start_f + min_duration_frames
                        if start_f - pre_start_f < min_duration_frames:
                            pre_start_f = start_f - min_duration_frames

                        max_value = max(0.0, min(1.0, strength / 100.0))

                        for obj in target_objects:
                            per_obj = mappings_by_objname.get(obj.name, {})
                            mapped = (per_obj.get(cluster_num) or "").strip()
                            if mapped and obj.data.shape_keys and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=pre_start_f)
                                kb.value = max_value
                                kb.keyframe_insert("value", frame=start_f)
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=end_f)

                    return None
                finally:
                    try:
                        bpy.context.scene.unomi.is_syncing = False
                    except Exception:
                        pass

            bpy.app.timers.register(apply_on_main, first_interval=0.0)

        except Exception:
            def reset_sync_state():
                try:
                    bpy.context.scene.unomi.is_syncing = False
                except Exception:
                    pass
                return None
            bpy.app.timers.register(reset_sync_state, first_interval=0.1)


classes = (UNOMI_OT_Sync,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass



