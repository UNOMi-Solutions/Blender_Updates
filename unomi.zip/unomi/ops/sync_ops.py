#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           1/20/26            Enhancements to auto update feature. Notifies user when to update and gets latest version.
#Jack Parent           1/30/26            Added multiple languages to lip sync.
#Jack Parent           3/01/26            Added Sync progress % display support.
#Jack Parent           3/01/26            Added token credit checks + consumption.

import os
import threading
import requests
import bpy
import time

from ..util.constants import PHONEMES
from ..util.mapping import get_object_phoneme_mapping
from ..util.state import USER
from ..auth.service import auth_service


def _tag_redraw_all():
    wm = bpy.context.window_manager
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()


def _seconds_to_hhmmss(seconds: float) -> str:
    sec = int(max(0, round(seconds)))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def resolve_service_url(lang_code: str) -> str:
    LANG_URLS = {
        "default": "https://lip-sync-phoneme-finder-konujgly4q-wl.a.run.app/",
        "it": "https://unomi-it-663811464633.us-west2.run.app/",
        "zh": "https://unomi-zh-663811464633.us-west2.run.app/",
        "ru": "https://unomi-ru-663811464633.us-west2.run.app/",
        "de": "https://unomi-de-663811464633.us-west2.run.app/",
        "es": "https://unomi-es-663811464633.us-west2.run.app/",
        "fr": "https://unomi-fr-663811464633.us-west2.run.app/",
        "jp": "https://unomi-jp-663811464633.us-west2.run.app/",
        #"ja": "https://unomi-jp-663811464633.us-west2.run.app/",
        "pt": "https://unomi-pt-663811464633.us-west2.run.app/",
    }

    code = (lang_code or "auto").strip().lower()
    if code in ("", "auto"):
        return LANG_URLS["default"]
    return LANG_URLS.get(code, LANG_URLS["default"])


class UNOMI_OT_Sync(bpy.types.Operator):
    bl_idname = "unomi.sync"
    bl_label = "Sync"
    bl_options = {'REGISTER', 'UNDO'}

    # -----------------------------
    # Progress heartbeat
    # -----------------------------
    def progress_heartbeat_timer(self):
        """
        Ensures the % keeps moving while syncing so the UI never looks frozen.

        - While waiting on Cloud Run: nudges progress up to 95%.
        - While applying keyframes: nudges progress up to 99%.
        - 100% is reserved ONLY for true completion.
        """
        u = getattr(bpy.context.scene, "unomi", None)
        if not u or not getattr(u, "is_syncing", False):
            return None  # stop timer

        now = time.monotonic()
        last = float(getattr(u, "last_progress_tick", 0.0))
        cur = int(getattr(u, "sync_progress", 0))

        if now - last >= 0.2:
            waiting = bool(getattr(u, "sync_waiting_response", False))
            if waiting:
                if cur < 95:
                    u.sync_progress = cur + 1
                    u.last_progress_tick = now
            else:
                if cur < 99:
                    u.sync_progress = cur + 1
                    u.last_progress_tick = now

            _tag_redraw_all()

        return 0.1

    # -----------------------------
    # Helpers
    # -----------------------------
    def _set_output(self, ok: bool, msg: str):
        u = getattr(bpy.context.scene, "unomi", None)
        if u:
            if hasattr(u, "last_sync_ok"):
                u.last_sync_ok = bool(ok)
            if hasattr(u, "last_sync_output"):
                u.last_sync_output = str(msg)
        _tag_redraw_all()

    def _reset_state(self, progress_to_zero: bool = True):
        u = getattr(bpy.context.scene, "unomi", None)
        if u:
            u.is_syncing = False
            u.sync_waiting_response = False
            if progress_to_zero:
                u.sync_progress = 0
            if hasattr(u, "last_progress_tick"):
                u.last_progress_tick = time.monotonic()
        _tag_redraw_all()

    def _require_login_and_any_credits(self) -> (bool, str, str):
        """
        Returns (ok, error_message, remaining_time_formatted).
        """
        if not getattr(auth_service, "token", "") or not getattr(auth_service, "product_id", ""):
            return False, "Please Login before syncing.", ""

        res = auth_service.available_credits()
        if not res or res.get("status") != "success":
            err = res.get("message") or res.get("error") or "Unable to check credits."
            return False, f"Credits check failed: {err}", ""

        remaining_fmt = res.get("available_credits", "")
        try:
            parts = remaining_fmt.split(":")
            remaining_seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        except Exception:
            remaining_seconds = 0

        if remaining_seconds <= 0:
            return False, "No credits remaining.", remaining_fmt

        return True, "", remaining_fmt

    # -----------------------------
    # Execute (main thread)
    # -----------------------------
    def execute(self, context):
        s = getattr(context.scene, "unomi", None)
        if not s:
            self.report({'ERROR'}, "UNOMi properties not registered (Scene.unomi missing).")
            return {'CANCELLED'}

        # Initialize sync state
        s.is_syncing = True
        s.sync_progress = 0
        s.sync_waiting_response = False
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()

        # Clear last output at start
        self._set_output(ok=False, msg="")

        # Start heartbeat
        bpy.app.timers.register(self.progress_heartbeat_timer)

        # -----------------------------
        # Validation (0 -> 10)
        # -----------------------------
        if s.use_multiple_objects:
            target_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            if not target_objects:
                self.report({'ERROR'}, "No mesh objects selected")
                self._reset_state(progress_to_zero=True)
                return {'CANCELLED'}
            if not s.target_obj:
                self.report({'ERROR'}, "Primary target object needed for shape key reference")
                self._reset_state(progress_to_zero=True)
                return {'CANCELLED'}
        else:
            if not s.target_obj:
                self.report({'ERROR'}, "No target object selected")
                self._reset_state(progress_to_zero=True)
                return {'CANCELLED'}
            target_objects = [s.target_obj]

        audio_abs = bpy.path.abspath(s.audio_path) if getattr(s, "audio_path", "") else ""
        if not audio_abs or not os.path.isfile(audio_abs):
            self.report({'ERROR'}, "Audio file not set or not found")
            self._reset_state(progress_to_zero=True)
            return {'CANCELLED'}

        script_text = (getattr(s, "script_text", "") or "").strip()
        if not script_text:
            self.report({'ERROR'}, "Script text is empty")
            self._reset_state(progress_to_zero=True)
            return {'CANCELLED'}

        # Credits pre-check (only "has any credits")
        ok, err, remaining_fmt = self._require_login_and_any_credits()
        if not ok:
            self.report({'ERROR'}, err)
            self._reset_state(progress_to_zero=True)
            return {'CANCELLED'}

        s.sync_progress = 10
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()
        _tag_redraw_all()

        # -----------------------------
        # Mapping build (10 -> 25)
        # -----------------------------
        target_object_names = [obj.name for obj in target_objects]
        mappings_by_objname = {}

        total_maps = max(1, len(target_objects) * len(PHONEMES))
        done_maps = 0

        for obj in target_objects:
            per_obj = {}
            for key, _ in PHONEMES:
                per_obj[key] = get_object_phoneme_mapping(obj, key)
                done_maps += 1
                s.sync_progress = 10 + int((done_maps / total_maps) * 15)
                if hasattr(s, "last_progress_tick"):
                    s.last_progress_tick = time.monotonic()
            mappings_by_objname[obj.name] = per_obj

        s.sync_progress = 25
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()
        _tag_redraw_all()

        # Prepare service request
        fps = bpy.context.scene.render.fps
        strength = getattr(s, "strength", 50)

        lang = (getattr(s, "language", "auto") or "auto").lower()
        service_url = resolve_service_url(lang)

        # Waiting phase
        s.sync_waiting_response = True
        if hasattr(s, "last_progress_tick"):
            s.last_progress_tick = time.monotonic()

        if remaining_fmt:
            self.report({'INFO'}, f"Syncing ({lang})... Credits: {remaining_fmt}")
        else:
            self.report({'INFO'}, f"Syncing ({lang})...")

        # Run request in background thread
        thread = threading.Thread(
            target=self._sync_thread,
            args=(
                target_object_names,
                mappings_by_objname,
                fps,
                strength,
                audio_abs,
                script_text,
                service_url,
                lang,
            ),
        )
        thread.daemon = True
        thread.start()

        return {'FINISHED'}

    # -----------------------------
    # Background thread
    # -----------------------------
    def _sync_thread(
        self,
        target_object_names,
        mappings_by_objname,
        fps,
        strength,
        audio_abs,
        script_text,
        service_url,
        lang,
    ):
        try:
            base = (service_url or "").strip()
            url = base.rstrip("/") + "/align"

            # Measure Cloud Run processing time accurately (wall-clock)
            server_start = time.monotonic()

            with open(audio_abs, "rb") as audio_fh:
                files = {
                    "text": ("text.txt", script_text.encode("utf-8"), "text/plain"),
                    "audio": (os.path.basename(audio_abs), audio_fh, "audio/wav"),
                }
                resp = requests.post(url, files=files, timeout=3600)

            server_elapsed = max(1.0, time.monotonic() - server_start)

            resp.raise_for_status()
            data = resp.json()
            phones = data.get("phonesTimes", [])

            # We'll charge credits ONLY after apply succeeds.
            apply_done = threading.Event()
            apply_result = {"ok": False, "msg": ""}

            # Mark response received (main thread)
            def mark_response_received():
                u = getattr(bpy.context.scene, "unomi", None)
                if u:
                    u.sync_waiting_response = False
                    u.sync_progress = max(int(getattr(u, "sync_progress", 0)), 95)
                    if hasattr(u, "last_progress_tick"):
                        u.last_progress_tick = time.monotonic()
                _tag_redraw_all()
                return None

            bpy.app.timers.register(mark_response_received, first_interval=0.0)

            # Apply keyframes (main thread)
            def apply_on_main():
                try:
                    scene = bpy.context.scene
                    s = getattr(scene, "unomi", None)
                    if not s:
                        apply_result["ok"] = False
                        apply_result["msg"] = "Sync failed X | Scene.unomi missing"
                        return None

                    target_objects = []
                    for name in target_object_names:
                        obj = bpy.data.objects.get(name)
                        if obj and obj.type == 'MESH':
                            target_objects.append(obj)

                    if not target_objects:
                        apply_result["ok"] = False
                        apply_result["msg"] = "Sync failed X | No target objects resolved"
                        return None

                    for obj in target_objects:
                        if not obj.data.shape_keys:
                            apply_result["ok"] = False
                            apply_result["msg"] = f"Sync failed X | {obj.name} has no shape keys"
                            return None

                    # Zero at frame 0
                    s.sync_progress = max(int(getattr(s, "sync_progress", 0)), 95)
                    if hasattr(s, "last_progress_tick"):
                        s.last_progress_tick = time.monotonic()

                    for obj in target_objects:
                        per_obj = mappings_by_objname.get(obj.name, {})
                        for key, _label in PHONEMES:
                            mapped = (per_obj.get(key) or "").strip()
                            if mapped and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=0)

                    # Trial/Free cap in animation application (keep your current behavior)
                    try:
                        is_trial_or_free = str(USER.get("status", "Trial")) in ("Trial", "Free")
                    except Exception:
                        is_trial_or_free = True

                    filtered_phones = phones
                    if is_trial_or_free:
                        CAP_SECONDS = 30.0
                        try:
                            filtered_phones = [
                                p for p in phones
                                if float(p.get("start_phone", 0.0)) <= CAP_SECONDS
                            ]
                        except Exception:
                            filtered_phones = phones

                    total = max(1, len(filtered_phones))

                    for i, p in enumerate(filtered_phones):
                        cluster = p.get("cluster", "")
                        try:
                            start = float(p.get("start_phone", 0.0))
                        except Exception:
                            start = 0.0
                        try:
                            end = float(p.get("end_phone", start))
                        except Exception:
                            end = start

                        cluster_num = cluster.replace("clu", "").zfill(2)

                        start_f = int(start * fps)
                        if i + 1 < len(phones):
                            try:
                                end_time = float(phones[i + 1].get("start_phone", end))
                            except Exception:
                                end_time = end
                        else:
                            end_time = end
                        end_f = int(end_time * fps)

                        if i > 0:
                            prev_phone = phones[i - 1]
                            try:
                                duration = start - float(prev_phone.get("start_phone", start))
                            except Exception:
                                duration = 0.0

                            if prev_phone.get("cluster") == "clu14" and duration > 0.2:
                                pre_start = start - 0.2
                            elif prev_phone.get("cluster") != cluster and duration > 0.4:
                                pre_start = start - 0.4
                            else:
                                try:
                                    pre_start = float(prev_phone.get("start_phone", start))
                                except Exception:
                                    pre_start = start
                        else:
                            pre_start = start - 0.2

                        pre_start_f = int(pre_start * fps)

                        min_duration_frames = 2
                        if end_f - start_f < min_duration_frames:
                            end_f = start_f + min_duration_frames
                        if start_f - pre_start_f < min_duration_frames:
                            pre_start_f = start_f - min_duration_frames

                        max_value = max(0.0, min(1.0, strength / 100.0))

                        for obj in target_objects:
                            per_obj = mappings_by_objname.get(obj.name, {})
                            mapped = (per_obj.get(cluster_num) or "").strip()
                            if mapped and obj.data.shape_keys and mapped in obj.data.shape_keys.key_blocks:
                                kb = obj.data.shape_keys.key_blocks[mapped]
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=pre_start_f)
                                kb.value = max_value
                                kb.keyframe_insert("value", frame=start_f)
                                kb.value = 0.0
                                kb.keyframe_insert("value", frame=end_f)

                        real_pct = 95 + int(((i + 1) / total) * 4)  # 95->99
                        s.sync_progress = max(int(getattr(s, "sync_progress", 0)), min(99, real_pct))
                        if hasattr(s, "last_progress_tick"):
                            s.last_progress_tick = time.monotonic()
                        _tag_redraw_all()

                    apply_result["ok"] = True
                    apply_result["msg"] = f"Sync complete ✅ | Lang: {lang.upper()} | Phones: {len(filtered_phones)} | Objects: {len(target_objects)}"
                    return None

                finally:
                    u = getattr(bpy.context.scene, "unomi", None)
                    if u:
                        u.is_syncing = False
                        u.sync_waiting_response = False
                        if hasattr(u, "last_progress_tick"):
                            u.last_progress_tick = time.monotonic()
                    _tag_redraw_all()
                    apply_done.set()

            bpy.app.timers.register(apply_on_main, first_interval=0.0)

            # Wait until apply finishes
            apply_done.wait(timeout=600.0)

            if not apply_result["ok"]:
                def fail_msg():
                    self._set_output(False, apply_result["msg"])
                    self.report({'ERROR'}, apply_result["msg"])
                    self._reset_state(progress_to_zero=True)
                    return None
                bpy.app.timers.register(fail_msg, first_interval=0.0)
                return

            # Consume credits based on server processing time
            charge_hhmmss = _seconds_to_hhmmss(server_elapsed)
            consume_res = auth_service.consume_credits(charge_hhmmss)

            final_msg = apply_result["msg"] + f" | Charged: {charge_hhmmss}"

            if consume_res and consume_res.get("success"):
                data = consume_res.get("data", {}) or {}
                remaining_fmt = data.get("remaining_time_formatted", "")
                if remaining_fmt:
                    final_msg += f" | Credits left: {remaining_fmt}"
                else:
                    final_msg += " | Credits updated"
            else:
                err = ""
                if isinstance(consume_res, dict):
                    err = consume_res.get("message") or consume_res.get("error") or ""
                final_msg += f" | Credit charge failed{(': ' + err) if err else ''}"

            def done_msg():
                s = getattr(bpy.context.scene, "unomi", None)
                if s:
                    s.sync_progress = 100
                    if hasattr(s, "last_progress_tick"):
                        s.last_progress_tick = time.monotonic()
                self._set_output(True, final_msg)
                self.report({'INFO'}, final_msg)
                _tag_redraw_all()
                return None

            bpy.app.timers.register(done_msg, first_interval=0.0)

        except Exception as e:
            print("Sync thread failed:", e)

            def reset_fail():
                self._set_output(False, f"Sync failed X | {str(e)}")
                self.report({'ERROR'}, f"Sync failed: {str(e)}")
                self._reset_state(progress_to_zero=True)
                return None

            bpy.app.timers.register(reset_fail, first_interval=0.0)


classes = (UNOMI_OT_Sync,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass