#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           1/30/26            Added multiple languages to lip sync.
#Jack Parent           3/01/26            Added Sync progress % display support.
#Jack Parent           3/01/26            Added token credit checks + consumption.

# Mapping-related properties and operators
# Defines `UNOMiProps` scene properties and operators to select target
# and update per-phoneme mappings on the chosen object.
import bpy
from ..util.constants import PHONEMES
from ..util.mapping import (
    get_object_phoneme_mapping,
    set_object_phoneme_mapping,
    sync_temp_mappings_from_object,
    update_temp_mapping,
)


class UNOMiProps(bpy.types.PropertyGroup):
    target_obj: bpy.props.PointerProperty(name="Target", type=bpy.types.Object, description="Target object for shape key reference")
    def on_target_name_change(self, context):
        self.target_obj = bpy.data.objects.get(self.target_obj_name) if getattr(self, "target_obj_name", "") else None
    target_obj_name: bpy.props.StringProperty(name="Target", default="", description="Target object (by name)", update=on_target_name_change)
    left_brow_shape: bpy.props.StringProperty(name="Left Brow", default="", description="Shape key for left brow")
    right_brow_shape: bpy.props.StringProperty(name="Right Brow", default="", description="Shape key for right brow")
    left_brow_high_shape: bpy.props.StringProperty(name="Left Brow High", default="", description="Shape key for left brow High")
    left_brow_low_shape: bpy.props.StringProperty(name="Left Brow Low", default="", description="Shape key for left brow Low")
    right_brow_high_shape: bpy.props.StringProperty(name="Right Brow High", default="", description="Shape key for right brow High")
    right_brow_low_shape: bpy.props.StringProperty(name="Right Brow Low", default="", description="Shape key for right brow Low")
    left_brow_strength: bpy.props.FloatProperty(name="Strength", default=50.0, min=0.0, max=100.0)
    right_brow_strength: bpy.props.FloatProperty(name="Strength", default=50.0, min=0.0, max=100.0)
    left_eyelid_shape: bpy.props.StringProperty(name="Left Eyelid",default="",description="Shape key for left eyelid")
    right_eyelid_shape: bpy.props.StringProperty(name="Right Eyelid",default="",description="Shape key for right eyelid")
    eyelid_blinks: bpy.props.BoolProperty(name="Eyelid Blinks",default=False)
    eyelid_random: bpy.props.BoolProperty(name="Eyelid Random",default=False)
    eyelid_strength: bpy.props.FloatProperty(name="Eyelid Strength",default=50.0,min=0.0,max=100.0)
    left_eye_shape: bpy.props.StringProperty(default="")
    right_eye_shape: bpy.props.StringProperty(default="")
    left_eye_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    right_eye_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    eye_jitter_enabled: bpy.props.BoolProperty(default=False)
    eye_jitter_amount: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    eye_jitter_x: bpy.props.BoolProperty(default=False)
    eye_jitter_y: bpy.props.BoolProperty(default=False)
    eye_jitter_xy: bpy.props.BoolProperty(default=False)
    eye_jitter_random: bpy.props.BoolProperty(default=False)
    left_cheek_shape: bpy.props.StringProperty(default="")
    right_cheek_shape: bpy.props.StringProperty(default="")
    left_cheek_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    right_cheek_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    cheek_physics: bpy.props.BoolProperty(default=False)
    cheek_physics_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    left_nostril_shape: bpy.props.StringProperty(default="")
    right_nostril_shape: bpy.props.StringProperty(default="")
    left_nostril_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    right_nostril_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    nostril_physics: bpy.props.BoolProperty(default=False)
    nostril_physics_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    left_ear_shape: bpy.props.StringProperty(default="")
    right_ear_shape: bpy.props.StringProperty(default="")
    left_ear_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    right_ear_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    ear_physics: bpy.props.BoolProperty(default=False)
    ear_physics_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    mouth_shape: bpy.props.StringProperty(default="")
    mouth_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    mouth_physics: bpy.props.BoolProperty(default=False)
    mouth_physics_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    joy_enabled: bpy.props.BoolProperty(default=False)
    joy_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    sadness_enabled: bpy.props.BoolProperty(default=False)
    sadness_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    anger_enabled: bpy.props.BoolProperty(default=False)
    anger_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    fear_enabled: bpy.props.BoolProperty(default=False)
    fear_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    surprise_enabled: bpy.props.BoolProperty(default=False)
    surprise_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    disgust_enabled: bpy.props.BoolProperty(default=False)
    disgust_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    contempt_enabled: bpy.props.BoolProperty(default=False)
    contempt_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    neutral_enabled: bpy.props.BoolProperty(default=False)
    neutral_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    laughter_enabled: bpy.props.BoolProperty(default=False)
    laughter_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    curiosity_enabled: bpy.props.BoolProperty(default=False)
    curiosity_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    pride_enabled: bpy.props.BoolProperty(default=False)
    pride_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    confusion_enabled: bpy.props.BoolProperty(default=False)
    confusion_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    embarrassment_enabled: bpy.props.BoolProperty(default=False)
    embarrassment_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)
    determination_enabled: bpy.props.BoolProperty(default=False)
    determination_strength: bpy.props.FloatProperty(default=50.0, min=0.0, max=100.0)

    use_multiple_objects: bpy.props.BoolProperty(name="Use Selected Objects", default=False, description="Apply lip sync to all selected objects instead of just primary target")
    strength: bpy.props.IntProperty(name="Strength", default=50, min=0, max=100)
    audio_path: bpy.props.StringProperty(name="Audio File", subtype='FILE_PATH')
    script_text: bpy.props.StringProperty(name="Script", default="", description="Paste or type script here", options={'TEXTEDIT_UPDATE'})

    mapping_target_obj: bpy.props.PointerProperty(
        name="Mapping Target",
        type=bpy.types.Object,
        description="Object whose phoneme mappings are currently being edited",
        update=lambda self, context: sync_temp_mappings_from_object(self, self.mapping_target_obj)
    )

    # Temporary properties for displaying current mappings with auto-update
    temp_map_01: bpy.props.StringProperty(name="O", default="", update=lambda s, c: update_temp_mapping(s, c, "01"))
    temp_map_02: bpy.props.StringProperty(name="A,E,I", default="", update=lambda s, c: update_temp_mapping(s, c, "02"))
    temp_map_03: bpy.props.StringProperty(name="Ee", default="", update=lambda s, c: update_temp_mapping(s, c, "03"))
    temp_map_04: bpy.props.StringProperty(name="Oo", default="", update=lambda s, c: update_temp_mapping(s, c, "04"))
    temp_map_05: bpy.props.StringProperty(name="C,D,G,K", default="", update=lambda s, c: update_temp_mapping(s, c, "05"))
    temp_map_06: bpy.props.StringProperty(name="B,M,P", default="", update=lambda s, c: update_temp_mapping(s, c, "06"))
    temp_map_07: bpy.props.StringProperty(name="F,V", default="", update=lambda s, c: update_temp_mapping(s, c, "07"))
    temp_map_08: bpy.props.StringProperty(name="Th", default="", update=lambda s, c: update_temp_mapping(s, c, "08"))
    temp_map_09: bpy.props.StringProperty(name="Q,W", default="", update=lambda s, c: update_temp_mapping(s, c, "09"))
    temp_map_10: bpy.props.StringProperty(name="Ch,J,Sh", default="", update=lambda s, c: update_temp_mapping(s, c, "10"))
    temp_map_11: bpy.props.StringProperty(name="R", default="", update=lambda s, c: update_temp_mapping(s, c, "11"))
    temp_map_12: bpy.props.StringProperty(name="L", default="", update=lambda s, c: update_temp_mapping(s, c, "12"))
    temp_map_13: bpy.props.StringProperty(name="Uh", default="", update=lambda s, c: update_temp_mapping(s, c, "13"))
    temp_map_14: bpy.props.StringProperty(name="Silent", default="", update=lambda s, c: update_temp_mapping(s, c, "14"))

    #Language List
    language: bpy.props.EnumProperty(
        name="Language",
        description="Language service used for lip sync",
        items=[
            ("auto", "Auto", "Use default service"),
            ("en", "English", ""),
            ("de", "German", ""),
            ("es", "Spanish", ""),
            ("fr", "French", ""),
            ("it", "Italian", ""),
            #("jp", "Japanese", ""),
            ("pt", "Portuguese", ""),
            ("ru", "Russian", ""),
            ("zh", "Chinese (Mandarin)", ""),
        ],
        default="auto",
    )

    # ---- Sync/progress state (SINGLE definition) ----
    is_syncing: bpy.props.BoolProperty(default=False)
    sync_progress: bpy.props.IntProperty(default=0, min=0, max=100)
    sync_waiting_response: bpy.props.BoolProperty(default=False)

        # ---- Sync output shown after completion ----
    last_sync_output: bpy.props.StringProperty(
        name="Last Sync Output",
        default="",
        description="Summary of the last sync run"
    )

    last_sync_ok: bpy.props.BoolProperty(
        name="Last Sync OK",
        default=False
    )

    # ---- Heartbeat bookkeeping (internal) ----
    last_progress_tick: bpy.props.FloatProperty(default=0.0)


class UNOMI_OT_SelectTarget(bpy.types.Operator):
    bl_idname = "unomi.select_target"
    bl_label = "Select"

    def execute(self, context):
        # set the active object as our target for mapping/sync
        s = context.scene.unomi
        s.target_obj = context.active_object
        if s.target_obj:
            self.report({'INFO'}, f"Target set to {s.target_obj.name}")
        else:
            self.report({'WARNING'}, "No active object selected")
        return {'FINISHED'}


class UNOMI_OT_UpdateMapping(bpy.types.Operator):
    bl_idname = "unomi.update_mapping"
    bl_label = "Update Mapping"

    phoneme_key: bpy.props.StringProperty()

    def execute(self, context):
        # persist the current temp mapping for this phoneme onto the object
        s = context.scene.unomi
        if s.mapping_target_obj and self.phoneme_key:
            temp_value = getattr(s, f"temp_map_{self.phoneme_key}", "")
            set_object_phoneme_mapping(s.mapping_target_obj, self.phoneme_key, temp_value)
        return {'FINISHED'}


class PhonemeMapping(bpy.types.PropertyGroup):
    value: bpy.props.StringProperty(name="Shape Key", default="")
    phoneme_key: bpy.props.StringProperty()

    def update_object_mapping(self, context):
        # when the value changes in UI, write it into the object immediately
        s = context.scene.unomi
        if s.mapping_target_obj and self.phoneme_key:
            set_object_phoneme_mapping(s.mapping_target_obj, self.phoneme_key, self.value)


classes = (
    UNOMiProps,
    UNOMI_OT_SelectTarget,
    UNOMI_OT_UpdateMapping,
    PhonemeMapping,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass