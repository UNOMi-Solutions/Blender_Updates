# UNOMi Blender Plugin

## Overview
The **UNOMi Blender Plugin** enables 3D lip-sync animation by analyzing speech audio and mapping phonemes to visemes (mouth shapes).  
It connects Blender to UNOMi’s cloud phoneme service and manages authentication, UI, and animation generation.

---

## Project Structure

### `__init__.py` – Main Plugin File
- Initializes and registers all plugin components.
- Loads and unloads preview icons.
- Attaches scene properties (`UNOMiProps`) for settings and mappings.
- Validates user authentication at startup.

---

### `/auth/` – Authentication
**`service.py`**
- Handles user sign-in, sign-out, and token validation.
- Uses WordPress JWT API for authentication.
- Stores login data in `auth_storage.json`.
- Includes device fingerprinting and session control.

---

### `/ops/` – Operations
**`io_ops.py`**
- Imports/exports plugin settings and phoneme mappings (JSON format).

**`mapping_ops.py`**
- Manages phoneme-to-shapekey mappings and target selection.

**`sync_ops.py`**
- Core lip-sync operator.
- Sends text and audio to UNOMi backend for phoneme analysis.
- Generates shape key keyframes based on phoneme timing.
- Runs network tasks in background threads for a responsive UI.

---

### `/ui/` – User Interface
**`menus.py`**
- Handles login/logout, tutorials, and help links.

**`panel.py`**
- Main sidebar panel (3D View → Sidebar → UNOMi tab).
- Displays:
  - User login status
  - Target selection
  - 14 phoneme icons with dropdown mappings
  - Strength slider
  - Audio/text inputs
  - Sync and Clear buttons

---

### `/util/` – Utilities
**`constants.py`**
- Defines the 14 phoneme categories (01–14).

**`mapping.py`**
- Manages phoneme mapping data and UI synchronization.

**`previews.py`**
- Loads and unloads icon previews for the UI.

**`state.py`**
- Stores in-memory user data (name and subscription status).

---

### `/icons/` – Visual Assets
- `01.png`–`14.png`: Phoneme icons.
- `unomi-logo1.png`: Plugin logo.

---

## Summary
The **UNOMi Blender Plugin** provides a full pipeline for generating 3D lip-sync animations:
1. Authenticate the user.
2. Upload audio and text.
3. Retrieve phoneme timings from the cloud.
4. Apply shape key animations inside Blender.
