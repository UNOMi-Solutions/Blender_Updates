#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           1/20/26            Enhancements to auto update feature. Notifies user when to update and gets latest version.
#Jack Parent           1/30/26            Added multiple languages to lip sync.
#Jack Parent           3/01/26            Added Sync progress % display support.
#Geanpierre Fernandez  7/29/26            Removed a debug print() that spammed the console on redraw.
#Abdullah Almesri      8/3/26             Draw Start Frame prop above the Sync button.
#Abdullah Almesri      8/3/26             Progress bar is now its own row; Sync button stays visible (disabled) during sync.
#Abdullah Almesri      8/3/26             Polished sync panel: progress row above buttons, reserved height, line separator, Clear stays enabled while syncing.

# Main UNOMi panel in the 3D View UI
# Shows menu row, logo, status, target, phoneme grid, and Sync/Clear.
import bpy
from .. import addon_updater_ops
from ..util.constants import PHONEMES
from ..util.previews import load_previews
from ..util.state import USER


class VIEW3D_PT_UNOMi(bpy.types.Panel):
    bl_label = "UNOMi Lip Sync"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UNOMi Lip Sync'

    def draw(self, context):
        s = context.scene.unomi
        layout = self.layout

        layout.scale_x = 4.0

        menu_row = layout.row(align=True)
        menu_row.scale_y = 1.0
        menu_row.operator("unomi.file_menu", text="File", icon='FILE')
        menu_row.operator("unomi.edit_menu", text="Edit")
        menu_row.operator("unomi.help_menu", text="Help", icon='HELP')
        if USER['name'] == "Guest":
            menu_row.operator("unomi.login", text="Login", icon='USER')
        else:
            menu_row.operator("unomi.logout", text="Logout", icon='USER')

        updater_box = layout.box()
        #addon_updater_ops.check_for_update_background(context)
        addon_updater_ops.update_notice_box_ui(self, context)

        main_box = layout.box()

        previews = load_previews()
        logo_row = main_box.row()
        logo_row.alignment = 'CENTER'
        if previews and 'unomi-logo1' in previews:
            logo_row.template_icon(previews['unomi-logo1'].icon_id, scale=4.0)
        else:
            logo_row.label(text="UNOMi", icon='WORLD')

        if USER['name'] != "Guest":
            main_box.label(text=f"User: {USER['name']} - {USER['status']}")

        row = main_box.row(align=True)
        if hasattr(s, "target_obj_name"):
            row.prop_search(s, "target_obj_name", bpy.data, "objects", text="Target")
        else:
            row.prop(s, "target_obj", text="Target")
        row.operator("unomi.select_target", text="Select")

        main_box.prop(s, "use_multiple_objects")
        if s.use_multiple_objects:
            selected_count = len([obj for obj in bpy.context.selected_objects if obj.type == 'MESH'])
            main_box.label(text=f"Selected mesh objects: {selected_count}")

        main_box.separator(factor=0.1)
        main_box.label(text="Edit Phoneme Mappings For:")
        main_box.prop(s, "mapping_target_obj", text="")
        main_box.separator()

        col_count = 3
        row = None
        for idx, (key, label) in enumerate(PHONEMES):
            if idx % col_count == 0:
                row = main_box.row(align=True)
            col = row.column(align=True)
            col.scale_x = 1.0
            col.scale_y = 0.8
            col.label(text=label)
            if previews and key in previews:
                col.template_icon(previews[key].icon_id, scale=6.0)
            if s.mapping_target_obj:
                temp_prop = f"temp_map_{key}"
                if s.mapping_target_obj.type == 'MESH' and s.mapping_target_obj.data.shape_keys:
                    col.prop_search(s, temp_prop, s.mapping_target_obj.data.shape_keys, "key_blocks", text="")
                else:
                    col.prop(s, temp_prop, text="")
            else:
                col.label(text="Select target", icon='INFO')

        remaining_cols = len(PHONEMES) % col_count
        if remaining_cols > 0:
            for _ in range(col_count - remaining_cols):
                empty_col = row.column(align=True)
                empty_col.scale_x = 1.0
                empty_col.label(text="")

        main_box.separator()
        main_box.prop(s, "strength", slider=True)
        main_box.separator()
        main_box.prop(s, "audio_path", text="Audio File")
        main_box.separator()
        main_box.prop(s, "language", text="Language")
        main_box.separator()
        main_box.label(text="Script")
        main_box.prop(s, "script_text", text="")
        main_box.separator()
        main_box.prop(s, "sync_start_frame")

        # --- action controls (progress + Sync/Clear) ---
        main_box.separator(type='LINE')

        syncing = bool(getattr(s, "is_syncing", False))
        progress = int(getattr(s, "sync_progress", 0))

        progress_row = main_box.row()
        if syncing:
            progress_row.progress(factor=progress / 100.0, text=f"Syncing... {progress}%")
        else:
            idle = progress_row.row()
            idle.enabled = False
            idle.label(text="Ready")

        row = main_box.row(align=True)
        sync_sub = row.row(align=True)
        sync_sub.enabled = not syncing
        sync_sub.operator("unomi.sync", text="Sync")
        row.operator("unomi.clear", icon='TRASH')

        addon_updater_ops.update_notice_box_ui(self, context)


class UNOMI_PT_Extra(bpy.types.Panel):
    bl_label = "UNOMi Facial Expressions"
    bl_idname = "UNOMI_PT_facial_expressions"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "UNOMi Expressions"

    def draw(self, context):
        s = context.scene.unomi
        layout = self.layout
        layout.scale_x = 4.0

        menu_row = layout.row(align=True)
        menu_row.scale_y = 1.0
        menu_row.operator("unomi.file_menu", text="File", icon='FILE')
        menu_row.operator("unomi.edit_menu", text="Edit")
        menu_row.operator("unomi.help_menu", text="Help", icon='HELP')
        if USER['name'] == "Guest":
            menu_row.operator("unomi.login", text="Login", icon='USER')
        else:
            menu_row.operator("unomi.logout", text="Logout", icon='USER')

        main_box = layout.box()

        previews = load_previews()
        logo_row = main_box.row()
        logo_row.alignment = 'CENTER'
        if previews and 'unomi-logo1' in previews:
            logo_row.template_icon(previews['unomi-logo1'].icon_id, scale=4.0)
        else:
            logo_row.label(text="UNOMi", icon='WORLD')

        if USER['name'] != "Guest":
            main_box.label(text=f"User: {USER['name']} - {USER['status']}")

        row = main_box.row(align=True)
        if hasattr(s, "target_obj_name"):
            row.prop_search(s, "target_obj_name", bpy.data, "objects", text="Target")
        else:
            row.prop(s, "target_obj", text="Target")
        row.operator("unomi.select_target", text="Select")

        main_box.prop(s, "use_multiple_objects")
        if s.use_multiple_objects:
            selected_count = len([obj for obj in bpy.context.selected_objects if obj.type == 'MESH'])
            main_box.label(text=f"Selected mesh objects: {selected_count}")

        eyes_box = main_box.box()
        eyes_box.alignment = 'CENTER'
        eyes_box.label(text="Eyes", icon='NONE')

        brows_row = eyes_box.row(align=True)
        left_col = brows_row.column(align=True)
        brows_row.separator(factor=3.0)
        right_col = brows_row.column(align=True)

        left_label = left_col.row()
        left_label.alignment = 'LEFT'
        left_label.label(text="Left Brow")

        # Left brow preview and controls
        left_icon_row = left_col.row()
        if previews and 'lefteyebrow' in previews:
            left_icon_row.template_icon(previews['lefteyebrow'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_col.prop_search(s, "left_brow_shape", s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_col.prop(s, "left_brow_shape", text="")
        #left_col.separator(factor=1)
        left_col.prop(s, "left_brow_strength", text="Strength", slider=True)

        # Right brow preview and controls
        right_label = right_col.row()
        right_label.alignment = 'LEFT'
        right_label.label(text="Right Brow")

        right_icon_row = right_col.row()
        if previews and 'righteyebrow' in previews:
            right_icon_row.template_icon(previews['righteyebrow'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_col.prop_search(s, "right_brow_shape", s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_col.prop(s, "right_brow_shape", text="")
        #right_col.separator(factor=1)
        right_col.prop(s, "right_brow_strength", text="Strength", slider=True)

        #Eyelids
        eyelids_row = eyes_box.row(align=True)
        left_eyelid_col = eyelids_row.column(align=True)
        eyelids_row.separator(factor=3.0)
        right_eyelid_col = eyelids_row.column(align=True)

        left_lbl = left_eyelid_col.row()
        left_lbl.alignment = 'LEFT'
        left_lbl.label(text="Left Eye Lids")

        left_icon = left_eyelid_col.row()
        if 'lefteyelid' in previews:
            left_icon.template_icon(previews['lefteyelid'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_eyelid_col.prop_search(s, "left_eyelid_shape",
                                        s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_eyelid_col.prop(s, "left_eyelid_shape", text="")

        right_lbl = right_eyelid_col.row()
        right_lbl.alignment = 'LEFT'
        right_lbl.label(text="Right Eye Lids")

        right_icon = right_eyelid_col.row()
        if 'righteyelid' in previews:
            right_icon.template_icon(previews['righteyelid'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_eyelid_col.prop_search(s, "right_eyelid_shape",
                                        s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_eyelid_col.prop(s, "right_eyelid_shape", text="")

        blink_row = eyes_box.row(align=True)
        blink_row.prop(s, "eyelid_blinks", text="Eye Blinks")
        blink_row.prop(s, "eyelid_strength", text="Strength", slider=True)

        rand_row = eyes_box.row(align=True)
        rand_row.prop(s, "eyelid_random", text="Random")

        #Eyes
        eyes2_row = eyes_box.row(align=True)
        left_eye_col = eyes2_row.column(align=True)
        eyes2_row.separator(factor=3.0)
        right_eye_col = eyes2_row.column(align=True)

        left_eye_lbl = left_eye_col.row()
        left_eye_lbl.alignment = 'LEFT'
        left_eye_lbl.label(text="Left Eye")

        left_eye_icon = left_eye_col.row()
        if 'lefteye' in previews:
            left_eye_icon.template_icon(previews['lefteye'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_eye_col.prop_search(s, "left_eye_shape",
                                    s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_eye_col.prop(s, "left_eye_shape", text="")

        left_eye_strength_row = left_eye_col.row(align=True)
        left_eye_strength_row.prop(s, "left_eye_strength", text="Strength", slider=True)

        right_eye_lbl = right_eye_col.row()
        right_eye_lbl.alignment = 'LEFT'
        right_eye_lbl.label(text="Right Eye")

        right_eye_icon = right_eye_col.row()
        if 'righteye' in previews:
            right_eye_icon.template_icon(previews['righteye'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_eye_col.prop_search(s, "right_eye_shape",
                                    s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_eye_col.prop(s, "right_eye_shape", text="")

        right_eye_strength_row = right_eye_col.row(align=True)
        right_eye_strength_row.prop(s, "right_eye_strength", text="Strength", slider=True)

        eye_jitter_row = eyes_box.row(align=True)
        eye_jitter_row.prop(s, "eye_jitter_enabled", text="Eye Jitter")
        eye_jitter_row.prop(s, "eye_jitter_amount", text="", slider=True)

        axis_row = eyes_box.row(align=True)
        axis_row.prop(s, "eye_jitter_x", text="X")
        axis_row.prop(s, "eye_jitter_y", text="Y")
        axis_row.prop(s, "eye_jitter_xy", text="XY")
        axis_row.prop(s, "eye_jitter_random", text="Random")

        #CHEEKS
        cheeks_box = main_box.box()
        cheeks_box.alignment = 'CENTER'
        cheeks_box.label(text="Cheeks")

        cheek_row = cheeks_box.row(align=True)
        left_cheek_col = cheek_row.column(align=True)
        cheek_row.separator(factor=3.0)
        right_cheek_col = cheek_row.column(align=True)

        left_cheek_label = left_cheek_col.row()
        left_cheek_label.alignment = 'LEFT'
        left_cheek_label.label(text="Left Cheek")

        left_cheek_icon = left_cheek_col.row()
        if 'leftcheek' in previews:
            left_cheek_icon.template_icon(previews['leftcheek'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_cheek_col.prop_search(s, "left_cheek_shape",
                                    s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_cheek_col.prop(s, "left_cheek_shape", text="")

        left_cheek_strength_row = left_cheek_col.row(align=True)
        left_cheek_strength_row.prop(s, "left_cheek_strength", text="Strength", slider=True)

        right_cheek_label = right_cheek_col.row()
        right_cheek_label.alignment = 'LEFT'
        right_cheek_label.label(text="Right Cheek")

        right_cheek_icon = right_cheek_col.row()
        if 'rightcheek' in previews:
            right_cheek_icon.template_icon(previews['rightcheek'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_cheek_col.prop_search(s, "right_cheek_shape",
                                        s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_cheek_col.prop(s, "right_cheek_shape", text="")

        right_cheek_strength_row = right_cheek_col.row(align=True)
        right_cheek_strength_row.prop(s, "right_cheek_strength", text="Strength", slider=True)

        cheek_physics_row = cheeks_box.row(align=True)
        cheek_physics_row.prop(s, "cheek_physics", text="Physics")
        cheek_physics_row.prop(s, "cheek_physics_strength", text="", slider=True)

        #NOSE
        nose_box = main_box.box()
        nose_box.alignment = 'CENTER'
        nose_box.label(text="Nose")

        nostril_row = nose_box.row(align=True)
        left_nostril_col = nostril_row.column(align=True)
        nostril_row.separator(factor=3.0)
        right_nostril_col = nostril_row.column(align=True)

        left_nostril_label = left_nostril_col.row()
        left_nostril_label.alignment = 'LEFT'
        left_nostril_label.label(text="Left Nostril")

        left_nostril_icon = left_nostril_col.row()
        if 'leftnostril' in previews:
            left_nostril_icon.template_icon(previews['leftnostril'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_nostril_col.prop_search(s, "left_nostril_shape",
                                        s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_nostril_col.prop(s, "left_nostril_shape", text="")

        left_nostril_strength_row = left_nostril_col.row(align=True)
        left_nostril_strength_row.prop(s, "left_nostril_strength", text="Strength", slider=True)

        right_nostril_label = right_nostril_col.row()
        right_nostril_label.alignment = 'LEFT'
        right_nostril_label.label(text="Right Nostril")

        right_nostril_icon = right_nostril_col.row()
        if 'rightnostril' in previews:
            right_nostril_icon.template_icon(previews['rightnostril'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_nostril_col.prop_search(s, "right_nostril_shape",
                                        s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_nostril_col.prop(s, "right_nostril_shape", text="")

        right_nostril_strength_row = right_nostril_col.row(align=True)
        right_nostril_strength_row.prop(s, "right_nostril_strength", text="Strength", slider=True)

        nostril_physics_row = nose_box.row(align=True)
        nostril_physics_row.prop(s, "nostril_physics", text="Physics")
        nostril_physics_row.prop(s, "nostril_physics_strength", text="", slider=True)

        #EARS
        ears_box = main_box.box()
        ears_box.alignment = 'CENTER'
        ears_box.label(text="Ears")

        ear_row = ears_box.row(align=True)
        left_ear_col = ear_row.column(align=True)
        ear_row.separator(factor=3.0)
        right_ear_col = ear_row.column(align=True)

        left_ear_label = left_ear_col.row()
        left_ear_label.alignment = 'LEFT'
        left_ear_label.label(text="Left Ear")

        left_ear_icon = left_ear_col.row()
        if 'leftear' in previews:
            left_ear_icon.template_icon(previews['leftear'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            left_ear_col.prop_search(s, "left_ear_shape",
                                    s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            left_ear_col.prop(s, "left_ear_shape", text="")

        left_ear_strength_row = left_ear_col.row(align=True)
        left_ear_strength_row.prop(s, "left_ear_strength", text="Strength", slider=True)

        right_ear_label = right_ear_col.row()
        right_ear_label.alignment = 'LEFT'
        right_ear_label.label(text="Right Ear")

        right_ear_icon = right_ear_col.row()
        if 'rightear' in previews:
            right_ear_icon.template_icon(previews['rightear'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            right_ear_col.prop_search(s, "right_ear_shape",
                                    s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            right_ear_col.prop(s, "right_ear_shape", text="")

        right_ear_strength_row = right_ear_col.row(align=True)
        right_ear_strength_row.prop(s, "right_ear_strength", text="Strength", slider=True)

        ear_physics_row = ears_box.row(align=True)
        ear_physics_row.prop(s, "ear_physics", text="Physics")
        ear_physics_row.prop(s, "ear_physics_strength", text="", slider=True)

        #MOUTH
        mouth_box = main_box.box()
        mouth_box.alignment = 'CENTER'
        mouth_box.label(text="Mouth")

        mouth_icon_row = mouth_box.row()
        if 'mouth' in previews:
            mouth_icon_row.template_icon(previews['mouth'].icon_id, scale=8.0)

        if s.target_obj and s.target_obj.type == 'MESH' and s.target_obj.data.shape_keys:
            mouth_box.prop_search(s, "mouth_shape",
                                s.target_obj.data.shape_keys, "key_blocks", text="")
        else:
            mouth_box.prop(s, "mouth_shape", text="")

        mouth_strength_row = mouth_box.row(align=True)
        mouth_strength_row.prop(s, "mouth_strength", text="Strength", slider=True)

        mouth_physics_row = mouth_box.row(align=True)
        mouth_physics_row.prop(s, "mouth_physics", text="Physics")
        mouth_physics_row.prop(s, "mouth_physics_strength", text="", slider=True)

        #EMOTIVE SETTINGS
        emotive_box = main_box.box()
        emotive_box.alignment = 'CENTER'
        emotive_box.label(text="Emotive Settings")

        emotions = [
            ("joy", "Joy"),
            ("sadness", "Sadness"),
            ("anger", "Anger"),
            ("fear", "Fear"),
            ("surprise", "Surprise"),
            ("disgust", "Disgust"),
            ("contempt", "Contempt"),
            ("neutral", "Neutral"),
            ("laughter", "Laughter"),
            ("curiosity", "Curiosity"),
            ("pride", "Pride"),
            ("confusion", "Confusion"),
            ("embarrassment", "Embarrassment"),
            ("determination", "Determination")
        ]

        for i in range(0, len(emotions), 2):
            row = emotive_box.row(align=True)

            left_key, left_label = emotions[i]
            left_col = row.box().column(align=True)
            left_head = left_col.row(align=True)
            left_head.prop(s, f"{left_key}_enabled", text="")
            left_head.label(text=left_label)

            left_slider = left_col.row(align=True)
            left_slider.prop(s, f"{left_key}_strength", text="", slider=True)

            if i + 1 < len(emotions):
                right_key, right_label = emotions[i+1]
                right_col = row.box().column(align=True)
                right_head = right_col.row(align=True)
                right_head.prop(s, f"{right_key}_enabled", text="")
                right_head.label(text=right_label)

                right_slider = right_col.row(align=True)
                right_slider.prop(s, f"{right_key}_strength", text="", slider=True)

        clear_row = emotive_box.row(align=True)
        clear_row.operator("unomi.clear_expressions", text="Clear", icon='TRASH')
        addon_updater_ops.update_notice_box_ui(self, context)


classes = (VIEW3D_PT_UNOMi,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass