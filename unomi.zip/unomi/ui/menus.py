#Update Log:
#Name                  #Date              #Description
#Jeremy Lin            11/25/25           Initial Commit
#Jack Parent           3/01/26            Added token credit checks + consumption.
#Geanpierre Fernandez  7/31/26            Login reads the real plan (fixes paid users capped to 30s).

# UI menu and utility operators
# Login/logout/register/help plus File/Edit wrapper menus for actions.
import bpy
from ..auth.service import auth_service
from ..util.state import USER


class UNOMI_OT_Login(bpy.types.Operator):
    bl_idname = "unomi.login"
    bl_label = "Login"
    bl_options = {'REGISTER', 'UNDO'}

    email: bpy.props.StringProperty(name="Email", default="")
    password: bpy.props.StringProperty(name="Password", default="", options={'HIDDEN'}, subtype='PASSWORD')

    def invoke(self, context, event):
        # open a small dialog to collect email/password
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter your UNOMi credentials:")
        layout.separator()
        layout.prop(self, "email", text="Email")
        layout.prop(self, "password", text="Password")

    def execute(self, context):
        # perform login and update USER so UI shows plan/email
        if not self.email or not self.password:
            self.report({'ERROR'}, "Please enter both email and password")
            return {'CANCELLED'}
        if auth_service:
            result = auth_service.signin(self.email, self.password)
            if result['success']:
                # signin() returns only {"success", "subscriptions"} (no "user"/
                # "subscription" keys), so the old code always fell back to "Free" and
                # capped paid users. Read the real plan from get_user_info() -- the same
                # verified call validate_startup_token() uses at startup.
                user_info = auth_service.get_user_info()
                if user_info.get('success'):
                    data = user_info.get('data', {})
                    USER["name"] = data.get('user', {}).get('email', self.email)
                    USER["status"] = data.get('subscription', {}).get('package', 'Free')
                else:
                    USER["name"] = self.email
                    USER["status"] = "Free"
                self.report({'INFO'}, f"Login successful! Status: {USER['status']}")
                return {'FINISHED'}
            else:
                error_msg = result.get('error', 'Login failed')
                if 'invalid' in error_msg.lower() or 'incorrect' in error_msg.lower():
                    self.report({'ERROR'}, error_msg)
                elif 'network' in error_msg.lower() or 'connection' in error_msg.lower():
                    self.report({'ERROR'}, "Network error. Please check your internet connection.")
                elif 'timeout' in error_msg.lower():
                    self.report({'ERROR'}, "Connection timeout. Please try again.")
                else:
                    self.report({'ERROR'}, error_msg)
                return {'CANCELLED'}
        else:
            USER["name"] = self.email
            USER["status"] = "Pro"
            self.report({'INFO'}, "Login successful! (Offline mode)")
            return {'FINISHED'}


class UNOMI_OT_Logout(bpy.types.Operator):
    bl_idname = "unomi.logout"
    bl_label = "Logout"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # sign out and reset UI to Guest/Trial
        if auth_service:
            auth_service.signout()
        USER["name"] = "Guest"
        USER["status"] = "Trial"
        self.report({'INFO'}, "Logged out successfully")
        return {'FINISHED'}


class UNOMI_OT_ForceLogout(bpy.types.Operator):
    bl_idname = "unomi.force_logout"
    bl_label = "Force Logout"
    bl_description = "Force logout by revoking server session"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # force server logout if token exists; otherwise just clear locally
        if auth_service and auth_service.token:
            result = auth_service.signout()
            if result.get('success'):
                USER["name"] = "Guest"
                USER["status"] = "Trial"
                self.report({'INFO'}, "Force logout completed")
            else:
                self.report({'ERROR'}, f"Force logout failed: {result.get('message', 'Unknown error')}")
        else:
            if auth_service:
                auth_service.signout()
            USER["name"] = "Guest"
            USER["status"] = "Trial"
            self.report({'INFO'}, "No active token; local session cleared")
        return {'FINISHED'}


class UNOMI_OT_Register(bpy.types.Operator):
    bl_idname = "unomi.register"
    bl_label = "Register"
    bl_description = "Open registration page"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open UNOMi registration page in the default browser
        import webbrowser
        webbrowser.open("https://getunomi.com/login")
        self.report({'INFO'}, "Opening registration page...")
        return {'FINISHED'}


class UNOMI_OT_Tutorial(bpy.types.Operator):
    bl_idname = "unomi.tutorial"
    bl_label = "Tutorial"
    bl_description = "Open tutorial video"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open tutorial video in the default browser
        import webbrowser
        webbrowser.open("https://www.youtube.com/watch?v=mHCKNkIuWHM")
        self.report({'INFO'}, "Opening tutorial video...")
        return {'FINISHED'}


class UNOMI_OT_Website(bpy.types.Operator):
    bl_idname = "unomi.website"
    bl_label = "Website"
    bl_description = "Open UNOMi website"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open UNOMi website in the default browser
        import webbrowser
        webbrowser.open("https://getunomi.com/")
        self.report({'INFO'}, "Opening website...")
        return {'FINISHED'}


class UNOMI_OT_Contact(bpy.types.Operator):
    bl_idname = "unomi.contact"
    bl_label = "Contact Us"
    bl_description = "Open contact page"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open contact page in the default browser
        import webbrowser
        webbrowser.open("https://getunomi.com/contact")
        self.report({'INFO'}, "Opening contact page...")
        return {'FINISHED'}


class UNOMI_OT_About(bpy.types.Operator):
    bl_idname = "unomi.about"
    bl_label = "About"
    bl_description = "Show about information"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # show a simple popup with version and credits
        bpy.context.window_manager.popup_menu(self.draw_about, title="About UNOMi Lip Sync", icon='INFO')
        return {'FINISHED'}

    def draw_about(self, menu, context):
        layout = menu.layout
        layout.label(text="UNOMi Lip Sync for Blender")
        layout.label(text="Version: 1.5.0")
        layout.separator()
        layout.label(text="Developed by UNOMi")
        layout.label(text="© 2024 UNOMi. All rights reserved")


class UNOMI_OT_FileMenu(bpy.types.Operator):
    bl_idname = "unomi.file_menu"
    bl_label = "File Menu"
    bl_description = "File operations"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open the File menu popup
        bpy.context.window_manager.popup_menu(self.draw_file_menu, title="File", icon='FILE')
        return {'FINISHED'}

    def draw_file_menu(self, menu, context):
        layout = menu.layout
        layout.operator("unomi.file_export", text="Export...", icon='EXPORT')
        layout.operator("unomi.file_import", text="Import...", icon='IMPORT')


class UNOMI_OT_FileExport(bpy.types.Operator):
    bl_idname = "unomi.file_export"
    bl_label = "Export"
    bl_description = "Export configuration"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # trigger export file picker
        bpy.ops.unomi.export_config('INVOKE_DEFAULT')
        return {'FINISHED'}


class UNOMI_OT_FileImport(bpy.types.Operator):
    bl_idname = "unomi.file_import"
    bl_label = "Import"
    bl_description = "Import configuration"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # trigger import file picker
        bpy.ops.unomi.import_config('INVOKE_DEFAULT')
        return {'FINISHED'}


class UNOMI_OT_EditMenu(bpy.types.Operator):
    bl_idname = "unomi.edit_menu"
    bl_label = "Edit Menu"
    bl_description = "Edit operations"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open the Edit menu popup
        bpy.context.window_manager.popup_menu(self.draw_edit_menu, title="Edit")
        return {'FINISHED'}

    def draw_edit_menu(self, menu, context):
        layout = menu.layout
        layout.operator("unomi.reset_fields", text="Reset Fields", icon='FILE_REFRESH')
        layout.operator("unomi.clear_keyframes", text="Clear Keyframes", icon='KEYFRAME_HLT')


class UNOMI_OT_HelpMenu(bpy.types.Operator):
    bl_idname = "unomi.help_menu"
    bl_label = "Help Menu"
    bl_description = "Help and support"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # open the Help menu popup
        bpy.context.window_manager.popup_menu(self.draw_help_menu, title="Help", icon='HELP')
        return {'FINISHED'}

    def draw_help_menu(self, menu, context):
        layout = menu.layout
        layout.operator("unomi.tutorial", text="Tutorial", icon='HELP')
        layout.operator("unomi.website", text="Website", icon='WORLD')
        layout.operator("unomi.contact", text="Contact Us", icon='URL')
        layout.operator("unomi.about", text="About", icon='INFO')


classes = (
    UNOMI_OT_Login,
    UNOMI_OT_Logout,
    UNOMI_OT_ForceLogout,
    UNOMI_OT_Register,
    UNOMI_OT_Tutorial,
    UNOMI_OT_Website,
    UNOMI_OT_Contact,
    UNOMI_OT_About,
    UNOMI_OT_FileMenu,
    UNOMI_OT_FileExport,
    UNOMI_OT_FileImport,
    UNOMI_OT_EditMenu,
    UNOMI_OT_HelpMenu,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            pass



